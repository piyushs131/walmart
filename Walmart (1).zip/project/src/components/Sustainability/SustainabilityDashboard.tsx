import React from 'react';
import { Leaf, TrendingDown, TrendingUp, Recycle, Zap } from 'lucide-react';
import { Shipment, Product } from '../../types';

interface SustainabilityDashboardProps {
  shipments: Shipment[];
  products: Product[];
}

export const SustainabilityDashboard: React.FC<SustainabilityDashboardProps> = ({ 
  shipments, 
  products 
}) => {
  const totalCO2 = shipments.reduce((sum, shipment) => sum + (shipment.sustainabilityScore || 0), 0);
  const avgSustainabilityScore = products.reduce((sum, product) => sum + product.sustainabilityScore, 0) / products.length;
  
  const transportModes = shipments.reduce((acc, shipment) => {
    acc[shipment.transportMode] = (acc[shipment.transportMode] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const sustainabilityMetrics = [
    {
      title: 'CO₂ Emissions',
      value: `${totalCO2.toFixed(1)} tons`,
      change: -12.3,
      icon: <Leaf className="h-6 w-6 text-green-600" />,
      color: 'green'
    },
    {
      title: 'Avg Sustainability Score',
      value: `${avgSustainabilityScore.toFixed(1)}/100`,
      change: 8.5,
      icon: <TrendingUp className="h-6 w-6 text-green-600" />,
      color: 'green'
    },
    {
      title: 'Recycling Rate',
      value: '94.2%',
      change: 3.1,
      icon: <Recycle className="h-6 w-6 text-blue-600" />,
      color: 'blue'
    },
    {
      title: 'Energy Efficiency',
      value: '87.5%',
      change: 5.2,
      icon: <Zap className="h-6 w-6 text-yellow-600" />,
      color: 'yellow'
    }
  ];

  const getTransportIcon = (mode: string) => {
    switch (mode) {
      case 'road': return '🚚';
      case 'rail': return '🚆';
      case 'air': return '✈️';
      case 'sea': return '🚢';
      default: return '📦';
    }
  };

  const getTransportEmissions = (mode: string) => {
    const emissions = {
      road: 62,
      rail: 22,
      air: 185,
      sea: 11,
      multimodal: 45
    };
    return emissions[mode as keyof typeof emissions] || 50;
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold text-gray-900">Sustainability Dashboard</h2>
        <div className="flex items-center space-x-2">
          <Leaf className="h-5 w-5 text-green-600" />
          <span className="text-sm text-gray-600">Environmental Impact Tracking</span>
        </div>
      </div>

      {/* Sustainability Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {sustainabilityMetrics.map((metric, index) => (
          <div key={index} className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">{metric.title}</p>
                <p className="text-2xl font-bold text-gray-900 mt-1">{metric.value}</p>
              </div>
              <div className="p-3 bg-gray-50 rounded-lg">
                {metric.icon}
              </div>
            </div>
            <div className="flex items-center mt-4">
              {metric.change > 0 ? (
                <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
              ) : (
                <TrendingDown className="h-4 w-4 text-red-500 mr-1" />
              )}
              <span className={`text-sm ${metric.change > 0 ? 'text-green-600' : 'text-red-600'}`}>
                {metric.change > 0 ? '+' : ''}{metric.change}%
              </span>
              <span className="text-sm text-gray-500 ml-1">vs last month</span>
            </div>
          </div>
        ))}
      </div>

      {/* Transport Mode Analysis */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Transport Mode Distribution</h3>
          <div className="space-y-4">
            {Object.entries(transportModes).map(([mode, count]) => (
              <div key={mode} className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <span className="text-2xl">{getTransportIcon(mode)}</span>
                  <div>
                    <p className="font-medium text-gray-900 capitalize">{mode}</p>
                    <p className="text-sm text-gray-600">{count} shipments</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium text-gray-900">
                    {getTransportEmissions(mode)} kg CO₂/km
                  </p>
                  <p className="text-xs text-gray-500">per shipment</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Sustainability Initiatives</h3>
          <div className="space-y-4">
            <div className="flex items-start space-x-3">
              <div className="w-2 h-2 bg-green-500 rounded-full mt-2"></div>
              <div>
                <p className="font-medium text-gray-900">Green Packaging Program</p>
                <p className="text-sm text-gray-600">
                  Reduced packaging waste by 23% through biodegradable materials
                </p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
              <div>
                <p className="font-medium text-gray-900">Electric Vehicle Fleet</p>
                <p className="text-sm text-gray-600">
                  15% of last-mile deliveries now use electric vehicles
                </p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <div className="w-2 h-2 bg-yellow-500 rounded-full mt-2"></div>
              <div>
                <p className="font-medium text-gray-900">Route Optimization</p>
                <p className="text-sm text-gray-600">
                  AI-powered routing reduced fuel consumption by 18%
                </p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <div className="w-2 h-2 bg-purple-500 rounded-full mt-2"></div>
              <div>
                <p className="font-medium text-gray-900">Carbon Offset Program</p>
                <p className="text-sm text-gray-600">
                  Offsetting 100% of air freight emissions through verified projects
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Recommendations */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <h3 className="text-lg font-medium text-gray-900 mb-4">Sustainability Recommendations</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-4 bg-green-50 rounded-lg border border-green-200">
            <h4 className="font-medium text-green-900">High Impact</h4>
            <p className="text-sm text-green-700 mt-1">
              Switch 25% of road shipments to rail transport for routes over 500km
            </p>
            <p className="text-xs text-green-600 mt-2">Potential: -1,200 tons CO₂/year</p>
          </div>
          <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
            <h4 className="font-medium text-blue-900">Medium Impact</h4>
            <p className="text-sm text-blue-700 mt-1">
              Implement dynamic routing to reduce empty miles by 15%
            </p>
            <p className="text-xs text-blue-600 mt-2">Potential: -800 tons CO₂/year</p>
          </div>
          <div className="p-4 bg-yellow-50 rounded-lg border border-yellow-200">
            <h4 className="font-medium text-yellow-900">Quick Win</h4>
            <p className="text-sm text-yellow-700 mt-1">
              Consolidate shipments to reduce packaging waste by 30%
            </p>
            <p className="text-xs text-yellow-600 mt-2">Potential: -500 tons CO₂/year</p>
          </div>
          <div className="p-4 bg-purple-50 rounded-lg border border-purple-200">
            <h4 className="font-medium text-purple-900">Innovation</h4>
            <p className="text-sm text-purple-700 mt-1">
              Pilot drone delivery for last-mile in urban areas
            </p>
            <p className="text-xs text-purple-600 mt-2">Potential: -200 tons CO₂/year</p>
          </div>
        </div>
      </div>
    </div>
  );
};