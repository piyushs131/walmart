import React, { useState } from 'react';
import { Shield, AlertTriangle, CheckCircle, XCircle, FileText, Calendar, Thermometer, Zap } from 'lucide-react';
import { Product, Document, Certification } from '../../types';

interface SafetyComplianceProps {
  products: Product[];
}

export const SafetyCompliance: React.FC<SafetyComplianceProps> = ({ products }) => {
  const [activeTab, setActiveTab] = useState('overview');

  const hazmatProducts = products.filter(p => p.category === 'hazardous');
  const pharmaProducts = products.filter(p => p.category === 'pharmaceuticals');
  const tempControlledProducts = products.filter(p => p.temperatureRange);

  const safetyMetrics = {
    totalIncidents: 2,
    complianceRate: 98.5,
    certificationsExpiring: 3,
    temperatureBreaches: 1,
    hazmatCompliance: 100,
    lastAudit: '2024-01-10'
  };

  const emergencyProcedures = [
    {
      id: '1',
      type: 'Fire Emergency',
      description: 'Immediate evacuation and fire suppression protocols',
      lastUpdated: '2024-01-01',
      status: 'current'
    },
    {
      id: '2',
      type: 'Chemical Spill',
      description: 'Hazardous material containment and cleanup procedures',
      lastUpdated: '2024-01-01',
      status: 'current'
    },
    {
      id: '3',
      type: 'Temperature Breach',
      description: 'Cold chain failure response and product isolation',
      lastUpdated: '2024-01-01',
      status: 'current'
    },
    {
      id: '4',
      type: 'Security Breach',
      description: 'Unauthorized access response and investigation protocols',
      lastUpdated: '2023-12-15',
      status: 'needs_review'
    }
  ];

  const certifications = [
    {
      id: '1',
      name: 'OSHA Safety Compliance',
      issuingBody: 'OSHA',
      issueDate: '2023-06-01',
      expiryDate: '2024-06-01',
      status: 'valid' as const,
      documentUrl: '/docs/osha-cert.pdf'
    },
    {
      id: '2',
      name: 'Hazmat Handling License',
      issuingBody: 'DOT',
      issueDate: '2023-03-15',
      expiryDate: '2024-03-15',
      status: 'valid' as const,
      documentUrl: '/docs/hazmat-license.pdf'
    },
    {
      id: '3',
      name: 'FDA Pharmaceutical Storage',
      issuingBody: 'FDA',
      issueDate: '2023-01-10',
      expiryDate: '2024-01-10',
      status: 'valid' as const,
      documentUrl: '/docs/fda-pharma.pdf'
    }
  ];

  const getHazardClassInfo = (hazardClass?: string) => {
    const hazardInfo = {
      class_1: { name: 'Explosives', color: 'bg-red-100 text-red-800', icon: '💥' },
      class_2: { name: 'Gases', color: 'bg-yellow-100 text-yellow-800', icon: '🌪️' },
      class_3: { name: 'Flammable Liquids', color: 'bg-orange-100 text-orange-800', icon: '🔥' },
      class_4: { name: 'Flammable Solids', color: 'bg-red-100 text-red-800', icon: '🔥' },
      class_5: { name: 'Oxidizers', color: 'bg-blue-100 text-blue-800', icon: '⚡' },
      class_6: { name: 'Toxic Substances', color: 'bg-purple-100 text-purple-800', icon: '☠️' },
      class_7: { name: 'Radioactive', color: 'bg-yellow-100 text-yellow-800', icon: '☢️' },
      class_8: { name: 'Corrosives', color: 'bg-green-100 text-green-800', icon: '🧪' },
      class_9: { name: 'Miscellaneous', color: 'bg-gray-100 text-gray-800', icon: '⚠️' }
    };
    return hazardClass ? hazardInfo[hazardClass as keyof typeof hazardInfo] : null;
  };

  const getCertificationStatus = (cert: Certification) => {
    const daysUntilExpiry = Math.ceil((new Date(cert.expiryDate).getTime() - Date.now()) / (1000 * 60 * 60 * 24));
    if (daysUntilExpiry <= 0) return { status: 'expired', color: 'text-red-600 bg-red-50' };
    if (daysUntilExpiry <= 30) return { status: 'expiring', color: 'text-orange-600 bg-orange-50' };
    return { status: 'valid', color: 'text-green-600 bg-green-50' };
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold text-gray-900">Safety & Compliance</h2>
        <div className="flex items-center space-x-2">
          <Shield className="h-5 w-5 text-blue-600" />
          <span className="text-sm text-gray-600">Last Audit: {safetyMetrics.lastAudit}</span>
        </div>
      </div>

      {/* Safety Metrics Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <div className="bg-white rounded-lg shadow-md p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Compliance Rate</p>
              <p className="text-2xl font-bold text-green-600">{safetyMetrics.complianceRate}%</p>
            </div>
            <CheckCircle className="h-8 w-8 text-green-600" />
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Incidents</p>
              <p className="text-2xl font-bold text-red-600">{safetyMetrics.totalIncidents}</p>
            </div>
            <AlertTriangle className="h-8 w-8 text-red-600" />
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Hazmat Compliance</p>
              <p className="text-2xl font-bold text-green-600">{safetyMetrics.hazmatCompliance}%</p>
            </div>
            <Shield className="h-8 w-8 text-green-600" />
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Temp Breaches</p>
              <p className="text-2xl font-bold text-orange-600">{safetyMetrics.temperatureBreaches}</p>
            </div>
            <Thermometer className="h-8 w-8 text-orange-600" />
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Certs Expiring</p>
              <p className="text-2xl font-bold text-yellow-600">{safetyMetrics.certificationsExpiring}</p>
            </div>
            <Calendar className="h-8 w-8 text-yellow-600" />
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Hazmat Products</p>
              <p className="text-2xl font-bold text-purple-600">{hazmatProducts.length}</p>
            </div>
            <Zap className="h-8 w-8 text-purple-600" />
          </div>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="bg-white rounded-lg shadow-md">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6">
            {[
              { id: 'overview', label: 'Overview' },
              { id: 'hazmat', label: 'Hazardous Materials' },
              { id: 'temperature', label: 'Temperature Control' },
              { id: 'certifications', label: 'Certifications' },
              { id: 'procedures', label: 'Emergency Procedures' }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === tab.id
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </nav>
        </div>

        <div className="p-6">
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-lg font-medium text-gray-900 mb-4">Recent Safety Alerts</h3>
                  <div className="space-y-3">
                    <div className="flex items-start space-x-3 p-3 bg-yellow-50 rounded-lg border border-yellow-200">
                      <AlertTriangle className="h-5 w-5 text-yellow-600 mt-0.5" />
                      <div>
                        <p className="font-medium text-yellow-900">Temperature Monitoring Alert</p>
                        <p className="text-sm text-yellow-700">Cold storage unit #3 temperature fluctuation detected</p>
                        <p className="text-xs text-yellow-600 mt-1">2 hours ago</p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-3 p-3 bg-blue-50 rounded-lg border border-blue-200">
                      <FileText className="h-5 w-5 text-blue-600 mt-0.5" />
                      <div>
                        <p className="font-medium text-blue-900">Certification Renewal Due</p>
                        <p className="text-sm text-blue-700">OSHA Safety Compliance expires in 30 days</p>
                        <p className="text-xs text-blue-600 mt-1">1 day ago</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-medium text-gray-900 mb-4">Compliance Summary</h3>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                      <span className="font-medium">Hazmat Handling</span>
                      <span className="text-green-600 font-medium">100% Compliant</span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                      <span className="font-medium">Temperature Control</span>
                      <span className="text-green-600 font-medium">98% Compliant</span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                      <span className="font-medium">Documentation</span>
                      <span className="text-yellow-600 font-medium">95% Complete</span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                      <span className="font-medium">Staff Training</span>
                      <span className="text-green-600 font-medium">100% Current</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'hazmat' && (
            <div className="space-y-6">
              <h3 className="text-lg font-medium text-gray-900">Hazardous Materials Inventory</h3>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Product</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Hazard Class</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Quantity</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Location</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Handling Instructions</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Compliance</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {hazmatProducts.map((product) => {
                      const hazardInfo = getHazardClassInfo(product.hazardClass);
                      return (
                        <tr key={product.id} className="hover:bg-gray-50">
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div>
                              <div className="text-sm font-medium text-gray-900">{product.name}</div>
                              <div className="text-sm text-gray-500">Batch: {product.batchNumber}</div>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            {hazardInfo && (
                              <span className={`px-2 py-1 text-xs font-medium rounded-full ${hazardInfo.color}`}>
                                {hazardInfo.icon} {hazardInfo.name}
                              </span>
                            )}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {product.quantity.toLocaleString()}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {product.warehouse}
                          </td>
                          <td className="px-6 py-4 text-sm text-gray-900 max-w-xs">
                            {product.handlingInstructions || 'Standard hazmat protocols'}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center space-x-2">
                              <CheckCircle className="h-4 w-4 text-green-500" />
                              <span className="text-sm text-green-600">Compliant</span>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'temperature' && (
            <div className="space-y-6">
              <h3 className="text-lg font-medium text-gray-900">Temperature-Controlled Products</h3>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="space-y-4">
                  {tempControlledProducts.map((product) => (
                    <div key={product.id} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex items-start justify-between">
                        <div>
                          <h4 className="font-medium text-gray-900">{product.name}</h4>
                          <p className="text-sm text-gray-600">Batch: {product.batchNumber}</p>
                          <p className="text-sm text-gray-600">Location: {product.warehouse}</p>
                        </div>
                        <div className="text-right">
                          <div className="flex items-center space-x-1">
                            <Thermometer className="h-4 w-4 text-blue-500" />
                            <span className="text-sm font-medium">
                              {product.temperatureRange?.min}° - {product.temperatureRange?.max}°{product.temperatureRange?.unit}
                            </span>
                          </div>
                          <div className="mt-1">
                            <span className="px-2 py-1 text-xs font-medium bg-green-100 text-green-800 rounded-full">
                              Within Range
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <div>
                  <h4 className="font-medium text-gray-900 mb-3">Temperature Monitoring Alerts</h4>
                  <div className="space-y-3">
                    <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                      <div className="flex items-center space-x-2">
                        <AlertTriangle className="h-4 w-4 text-yellow-600" />
                        <span className="font-medium text-yellow-900">Minor Temperature Fluctuation</span>
                      </div>
                      <p className="text-sm text-yellow-700 mt-1">
                        Cold Storage Unit #3: Temperature rose to 6°C for 15 minutes
                      </p>
                      <p className="text-xs text-yellow-600 mt-1">2 hours ago</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'certifications' && (
            <div className="space-y-6">
              <h3 className="text-lg font-medium text-gray-900">Safety Certifications</h3>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {certifications.map((cert) => {
                  const status = getCertificationStatus(cert);
                  return (
                    <div key={cert.id} className="border border-gray-200 rounded-lg p-6">
                      <div className="flex items-start justify-between">
                        <div>
                          <h4 className="font-medium text-gray-900">{cert.name}</h4>
                          <p className="text-sm text-gray-600">Issued by: {cert.issuingBody}</p>
                          <p className="text-sm text-gray-600">
                            Valid: {new Date(cert.issueDate).toLocaleDateString()} - {new Date(cert.expiryDate).toLocaleDateString()}
                          </p>
                        </div>
                        <span className={`px-2 py-1 text-xs font-medium rounded-full ${status.color}`}>
                          {status.status}
                        </span>
                      </div>
                      <div className="mt-4 flex space-x-2">
                        <button className="px-3 py-1 bg-blue-600 text-white text-sm rounded hover:bg-blue-700 transition-colors">
                          View Certificate
                        </button>
                        <button className="px-3 py-1 bg-gray-100 text-gray-700 text-sm rounded hover:bg-gray-200 transition-colors">
                          Renew
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {activeTab === 'procedures' && (
            <div className="space-y-6">
              <h3 className="text-lg font-medium text-gray-900">Emergency Response Procedures</h3>
              <div className="space-y-4">
                {emergencyProcedures.map((procedure) => (
                  <div key={procedure.id} className="border border-gray-200 rounded-lg p-6">
                    <div className="flex items-start justify-between">
                      <div>
                        <h4 className="font-medium text-gray-900">{procedure.type}</h4>
                        <p className="text-sm text-gray-600 mt-1">{procedure.description}</p>
                        <p className="text-xs text-gray-500 mt-2">
                          Last updated: {new Date(procedure.lastUpdated).toLocaleDateString()}
                        </p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                          procedure.status === 'current' 
                            ? 'bg-green-100 text-green-800' 
                            : 'bg-yellow-100 text-yellow-800'
                        }`}>
                          {procedure.status === 'current' ? 'Current' : 'Needs Review'}
                        </span>
                        <button className="px-3 py-1 bg-blue-600 text-white text-sm rounded hover:bg-blue-700 transition-colors">
                          View Procedure
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};