import React from 'react';
import { MetricsCard } from './MetricsCard';
import { ChartContainer } from '../Charts/ChartContainer';
import { AlertsList } from '../Alerts/AlertsList';
import { 
  Package, 
  Truck, 
  Warehouse, 
  TrendingUp, 
  Leaf, 
  Shield, 
  Clock, 
  DollarSign,
  Activity,
  Users,
  AlertTriangle,
  CheckCircle
} from 'lucide-react';
import { mockAnalytics, mockInventoryAlerts, mockRiskAlerts } from '../../data/mockData';

export const Dashboard: React.FC = () => {
  const shipmentTrendData = [
    { month: 'Jan', shipments: 1200, delivered: 1150 },
    { month: 'Feb', shipments: 1350, delivered: 1300 },
    { month: 'Mar', shipments: 1400, delivered: 1380 },
    { month: 'Apr', shipments: 1580, delivered: 1520 },
    { month: 'May', shipments: 1650, delivered: 1600 },
    { month: 'Jun', shipments: 1750, delivered: 1720 }
  ];

  const sustainabilityData = [
    { category: 'Road', emissions: 45, efficiency: 78 },
    { category: 'Rail', emissions: 20, efficiency: 92 },
    { category: 'Air', emissions: 85, efficiency: 65 },
    { category: 'Sea', emissions: 15, efficiency: 88 }
  ];

  return (
    <div className="space-y-8">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Dashboard Overview</h1>
          <p className="mt-1 text-sm text-slate-600">
            Real-time insights into your supply chain operations
          </p>
        </div>
        <div className="mt-4 sm:mt-0 flex items-center space-x-3">
          <div className="flex items-center space-x-2 text-sm text-slate-600">
            <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
            <span>Live Data</span>
          </div>
          <span className="text-sm text-slate-500">Last updated: 2 minutes ago</span>
        </div>
      </div>

      {/* Primary Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricsCard
          title="Total Shipments"
          value={mockAnalytics.totalShipments.toLocaleString()}
          change={12.5}
          changeType="positive"
          icon={<Truck className="h-6 w-6 text-blue-600" />}
          subtitle="This month"
        />
        <MetricsCard
          title="On-Time Delivery"
          value={`${mockAnalytics.onTimeDelivery}%`}
          change={2.3}
          changeType="positive"
          icon={<Clock className="h-6 w-6 text-emerald-600" />}
          subtitle="Performance rate"
        />
        <MetricsCard
          title="Cost Savings"
          value={`$${mockAnalytics.costSavings}M`}
          change={8.7}
          changeType="positive"
          icon={<DollarSign className="h-6 w-6 text-emerald-600" />}
          subtitle="YTD savings"
        />
        <MetricsCard
          title="Sustainability Score"
          value={mockAnalytics.sustainabilityScore}
          change={5.2}
          changeType="positive"
          icon={<Leaf className="h-6 w-6 text-emerald-600" />}
          subtitle="Environmental impact"
        />
      </div>

      {/* Secondary Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricsCard
          title="Inventory Turnover"
          value={mockAnalytics.inventoryTurnover}
          change={-1.2}
          changeType="negative"
          icon={<Package className="h-6 w-6 text-amber-600" />}
          subtitle="Times per year"
        />
        <MetricsCard
          title="Risk Mitigation"
          value={`${mockAnalytics.riskMitigated}%`}
          change={3.4}
          changeType="positive"
          icon={<Shield className="h-6 w-6 text-purple-600" />}
          subtitle="Risk reduction"
        />
        <MetricsCard
          title="Customer Satisfaction"
          value={`${mockAnalytics.customerSatisfaction}%`}
          change={1.8}
          changeType="positive"
          icon={<Users className="h-6 w-6 text-blue-600" />}
          subtitle="CSAT score"
        />
        <MetricsCard
          title="Warehouse Efficiency"
          value={`${mockAnalytics.warehouseEfficiency}%`}
          change={4.1}
          changeType="positive"
          icon={<Warehouse className="h-6 w-6 text-indigo-600" />}
          subtitle="Operational efficiency"
        />
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
        <ChartContainer
          title="Shipment Performance Trends"
          subtitle="Monthly shipment volume and delivery performance"
          data={shipmentTrendData}
          chartType="line"
        />
        <ChartContainer
          title="Sustainability Impact by Transport Mode"
          subtitle="CO₂ emissions and efficiency metrics"
          data={sustainabilityData}
          chartType="bar"
        />
      </div>

      {/* Alerts and Activity */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
        <AlertsList
          title="Inventory Alerts"
          alerts={mockInventoryAlerts}
          type="inventory"
        />
        <AlertsList
          title="Risk & Compliance Alerts"
          alerts={mockRiskAlerts}
          type="risk"
        />
      </div>

      {/* Quick Actions */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <h3 className="text-lg font-semibold text-slate-900 mb-4">Quick Actions</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <button className="flex items-center space-x-3 p-4 rounded-lg border border-slate-200 hover:border-blue-300 hover:bg-blue-50 transition-all duration-200 group">
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center group-hover:bg-blue-200 transition-colors">
              <Package className="h-5 w-5 text-blue-600" />
            </div>
            <div className="text-left">
              <p className="font-medium text-slate-900">Add Inventory</p>
              <p className="text-sm text-slate-500">Create new stock entry</p>
            </div>
          </button>
          
          <button className="flex items-center space-x-3 p-4 rounded-lg border border-slate-200 hover:border-emerald-300 hover:bg-emerald-50 transition-all duration-200 group">
            <div className="w-10 h-10 bg-emerald-100 rounded-lg flex items-center justify-center group-hover:bg-emerald-200 transition-colors">
              <Truck className="h-5 w-5 text-emerald-600" />
            </div>
            <div className="text-left">
              <p className="font-medium text-slate-900">Track Shipment</p>
              <p className="text-sm text-slate-500">Monitor delivery status</p>
            </div>
          </button>
          
          <button className="flex items-center space-x-3 p-4 rounded-lg border border-slate-200 hover:border-purple-300 hover:bg-purple-50 transition-all duration-200 group">
            <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center group-hover:bg-purple-200 transition-colors">
              <Users className="h-5 w-5 text-purple-600" />
            </div>
            <div className="text-left">
              <p className="font-medium text-slate-900">Manage Suppliers</p>
              <p className="text-sm text-slate-500">Update supplier info</p>
            </div>
          </button>
          
          <button className="flex items-center space-x-3 p-4 rounded-lg border border-slate-200 hover:border-amber-300 hover:bg-amber-50 transition-all duration-200 group">
            <div className="w-10 h-10 bg-amber-100 rounded-lg flex items-center justify-center group-hover:bg-amber-200 transition-colors">
              <TrendingUp className="h-5 w-5 text-amber-600" />
            </div>
            <div className="text-left">
              <p className="font-medium text-slate-900">View Analytics</p>
              <p className="text-sm text-slate-500">Performance insights</p>
            </div>
          </button>
        </div>
      </div>
    </div>
  );
};