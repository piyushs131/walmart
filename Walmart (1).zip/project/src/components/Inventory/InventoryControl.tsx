import React, { useState } from 'react';
import { Search, Filter, Download, AlertTriangle, CheckCircle, XCircle, Thermometer, Package, Calendar, BarChart3 } from 'lucide-react';
import { Product, InventoryAlert } from '../../types';

interface InventoryControlProps {
  products: Product[];
  alerts: InventoryAlert[];
}

export const InventoryControl: React.FC<InventoryControlProps> = ({ products, alerts }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCategory, setFilterCategory] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');
  const [sortBy, setSortBy] = useState('name');
  const [viewMode, setViewMode] = useState<'table' | 'cards'>('table');

  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         product.batchNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         product.barcode.includes(searchTerm);
    const matchesCategory = filterCategory === 'all' || product.category === filterCategory;
    const matchesStatus = filterStatus === 'all' || 
      (filterStatus === 'low_stock' && product.quantity <= product.reorderPoint) ||
      (filterStatus === 'expiring_soon' && product.expiryDate && 
        new Date(product.expiryDate) <= new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)) ||
      (filterStatus === 'normal' && product.quantity > product.reorderPoint);
    
    return matchesSearch && matchesCategory && matchesStatus;
  }).sort((a, b) => {
    switch (sortBy) {
      case 'name': return a.name.localeCompare(b.name);
      case 'quantity': return b.quantity - a.quantity;
      case 'expiry': 
        if (!a.expiryDate && !b.expiryDate) return 0;
        if (!a.expiryDate) return 1;
        if (!b.expiryDate) return -1;
        return new Date(a.expiryDate).getTime() - new Date(b.expiryDate).getTime();
      case 'fifo': return new Date(a.fifoDate).getTime() - new Date(b.fifoDate).getTime();
      default: return 0;
    }
  });

  const getStockStatus = (product: Product) => {
    if (product.quantity <= product.minStock) return { status: 'critical', color: 'text-red-600 bg-red-50' };
    if (product.quantity <= product.reorderPoint) return { status: 'low', color: 'text-yellow-600 bg-yellow-50' };
    if (product.quantity >= product.maxStock * 0.9) return { status: 'high', color: 'text-blue-600 bg-blue-50' };
    return { status: 'normal', color: 'text-green-600 bg-green-50' };
  };

  const getExpiryStatus = (expiryDate?: string) => {
    if (!expiryDate) return null;
    const daysUntilExpiry = Math.ceil((new Date(expiryDate).getTime() - Date.now()) / (1000 * 60 * 60 * 24));
    if (daysUntilExpiry <= 0) return { status: 'expired', color: 'text-red-600 bg-red-50', text: 'Expired' };
    if (daysUntilExpiry <= 7) return { status: 'expiring', color: 'text-orange-600 bg-orange-50', text: `${daysUntilExpiry}d` };
    if (daysUntilExpiry <= 30) return { status: 'warning', color: 'text-yellow-600 bg-yellow-50', text: `${daysUntilExpiry}d` };
    return { status: 'good', color: 'text-green-600 bg-green-50', text: `${daysUntilExpiry}d` };
  };

  const getComplianceIcon = (status: string) => {
    switch (status) {
      case 'compliant': return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'non_compliant': return <XCircle className="h-4 w-4 text-red-500" />;
      case 'pending_review': return <AlertTriangle className="h-4 w-4 text-yellow-500" />;
      default: return <AlertTriangle className="h-4 w-4 text-gray-500" />;
    }
  };

  const getTemperatureStatus = (product: Product) => {
    if (!product.temperatureRange) return null;
    // Simulate current temperature reading
    const currentTemp = 3; // Mock current temperature
    const { min, max } = product.temperatureRange;
    if (currentTemp < min || currentTemp > max) {
      return { status: 'breach', color: 'text-red-600', icon: <Thermometer className="h-4 w-4 text-red-500" /> };
    }
    return { status: 'normal', color: 'text-green-600', icon: <Thermometer className="h-4 w-4 text-green-500" /> };
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold text-gray-900">Inventory Control</h2>
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setViewMode(viewMode === 'table' ? 'cards' : 'table')}
            className="px-3 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
          >
            {viewMode === 'table' ? 'Card View' : 'Table View'}
          </button>
          <button className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
            <Download className="h-4 w-4" />
            <span>Export</span>
          </button>
        </div>
      </div>

      {/* Inventory Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-lg shadow-md p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Products</p>
              <p className="text-2xl font-bold text-gray-900">{products.length}</p>
            </div>
            <Package className="h-8 w-8 text-blue-600" />
          </div>
        </div>
        <div className="bg-white rounded-lg shadow-md p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Low Stock Items</p>
              <p className="text-2xl font-bold text-red-600">
                {products.filter(p => p.quantity <= p.reorderPoint).length}
              </p>
            </div>
            <AlertTriangle className="h-8 w-8 text-red-600" />
          </div>
        </div>
        <div className="bg-white rounded-lg shadow-md p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Expiring Soon</p>
              <p className="text-2xl font-bold text-orange-600">
                {products.filter(p => p.expiryDate && 
                  new Date(p.expiryDate) <= new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)).length}
              </p>
            </div>
            <Calendar className="h-8 w-8 text-orange-600" />
          </div>
        </div>
        <div className="bg-white rounded-lg shadow-md p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Value</p>
              <p className="text-2xl font-bold text-green-600">
                ${products.reduce((sum, p) => sum + (p.quantity * p.price), 0).toLocaleString()}
              </p>
            </div>
            <BarChart3 className="h-8 w-8 text-green-600" />
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <input
              type="text"
              placeholder="Search products, batch, barcode..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <select
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="all">All Categories</option>
            <option value="groceries">Groceries</option>
            <option value="hazardous">Hazardous</option>
            <option value="pharmaceuticals">Pharmaceuticals</option>
            <option value="perishables">Perishables</option>
            <option value="electronics">Electronics</option>
          </select>
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="all">All Status</option>
            <option value="normal">Normal Stock</option>
            <option value="low_stock">Low Stock</option>
            <option value="expiring_soon">Expiring Soon</option>
          </select>
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="name">Sort by Name</option>
            <option value="quantity">Sort by Quantity</option>
            <option value="expiry">Sort by Expiry</option>
            <option value="fifo">Sort by FIFO</option>
          </select>
        </div>
      </div>

      {/* Inventory Display */}
      {viewMode === 'table' ? (
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Product</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Stock Level</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Location</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Expiry</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Temperature</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Compliance</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredProducts.map((product) => {
                  const stockStatus = getStockStatus(product);
                  const expiryStatus = getExpiryStatus(product.expiryDate);
                  const tempStatus = getTemperatureStatus(product);
                  
                  return (
                    <tr key={product.id} className="hover:bg-gray-50 transition-colors">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div>
                          <div className="text-sm font-medium text-gray-900">{product.name}</div>
                          <div className="text-sm text-gray-500">
                            Batch: {product.batchNumber} • Barcode: {product.barcode}
                          </div>
                          {product.rfidTag && (
                            <div className="text-xs text-blue-600">RFID: {product.rfidTag}</div>
                          )}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className="px-2 py-1 text-xs font-medium bg-gray-100 text-gray-800 rounded-full capitalize">
                          {product.category}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div>
                          <div className="text-sm font-medium text-gray-900">
                            {product.quantity.toLocaleString()}
                          </div>
                          <span className={`px-2 py-1 text-xs font-medium rounded-full ${stockStatus.color}`}>
                            {stockStatus.status}
                          </span>
                          <div className="text-xs text-gray-500 mt-1">
                            Reorder: {product.reorderPoint} • Max: {product.maxStock}
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {product.warehouse}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {expiryStatus ? (
                          <span className={`px-2 py-1 text-xs font-medium rounded-full ${expiryStatus.color}`}>
                            {expiryStatus.text}
                          </span>
                        ) : (
                          <span className="text-sm text-gray-500">N/A</span>
                        )}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {tempStatus ? (
                          <div className="flex items-center space-x-1">
                            {tempStatus.icon}
                            <span className={`text-xs ${tempStatus.color}`}>
                              {product.temperatureRange?.min}°-{product.temperatureRange?.max}°{product.temperatureRange?.unit}
                            </span>
                          </div>
                        ) : (
                          <span className="text-sm text-gray-500">N/A</span>
                        )}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center space-x-2">
                          {getComplianceIcon(product.complianceStatus)}
                          <span className="text-sm capitalize">{product.complianceStatus.replace('_', ' ')}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <button className="text-blue-600 hover:text-blue-900 mr-3">Edit</button>
                        <button className="text-green-600 hover:text-green-900 mr-3">Reorder</button>
                        <button className="text-gray-600 hover:text-gray-900">History</button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProducts.map((product) => {
            const stockStatus = getStockStatus(product);
            const expiryStatus = getExpiryStatus(product.expiryDate);
            const tempStatus = getTemperatureStatus(product);
            
            return (
              <div key={product.id} className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="text-lg font-medium text-gray-900">{product.name}</h3>
                    <p className="text-sm text-gray-600">Batch: {product.batchNumber}</p>
                  </div>
                  <span className={`px-2 py-1 text-xs font-medium rounded-full ${stockStatus.color}`}>
                    {stockStatus.status}
                  </span>
                </div>

                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-500">Current Stock:</span>
                    <span className="text-sm font-medium">{product.quantity.toLocaleString()}</span>
                  </div>
                  
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-500">Location:</span>
                    <span className="text-sm font-medium">{product.warehouse}</span>
                  </div>

                  {expiryStatus && (
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-500">Expiry:</span>
                      <span className={`px-2 py-1 text-xs font-medium rounded-full ${expiryStatus.color}`}>
                        {expiryStatus.text}
                      </span>
                    </div>
                  )}

                  {tempStatus && (
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-500">Temperature:</span>
                      <div className="flex items-center space-x-1">
                        {tempStatus.icon}
                        <span className={`text-xs ${tempStatus.color}`}>
                          {product.temperatureRange?.min}°-{product.temperatureRange?.max}°{product.temperatureRange?.unit}
                        </span>
                      </div>
                    </div>
                  )}

                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-500">Compliance:</span>
                    <div className="flex items-center space-x-1">
                      {getComplianceIcon(product.complianceStatus)}
                      <span className="text-xs capitalize">{product.complianceStatus.replace('_', ' ')}</span>
                    </div>
                  </div>
                </div>

                <div className="mt-4 pt-4 border-t border-gray-200">
                  <div className="flex space-x-2">
                    <button className="flex-1 px-3 py-2 bg-blue-600 text-white text-sm rounded-md hover:bg-blue-700 transition-colors">
                      Edit
                    </button>
                    <button className="flex-1 px-3 py-2 bg-green-600 text-white text-sm rounded-md hover:bg-green-700 transition-colors">
                      Reorder
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};