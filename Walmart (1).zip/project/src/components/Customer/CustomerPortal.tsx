import React, { useState } from 'react';
import { Search, Package, MapPin, Clock, Star, QrCode, Download, CheckCircle } from 'lucide-react';
import { Shipment } from '../../types';

interface CustomerPortalProps {
  shipments: Shipment[];
}

export const CustomerPortal: React.FC<CustomerPortalProps> = ({ shipments }) => {
  const [trackingNumber, setTrackingNumber] = useState('');
  const [selectedShipment, setSelectedShipment] = useState<Shipment | null>(null);

  const handleTrackingSearch = () => {
    const found = shipments.find(s => s.trackingNumber === trackingNumber);
    setSelectedShipment(found || null);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'delivered': return 'text-green-600 bg-green-50';
      case 'in_transit': return 'text-blue-600 bg-blue-50';
      case 'out_for_delivery': return 'text-purple-600 bg-purple-50';
      case 'delayed': return 'text-red-600 bg-red-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h1 className="text-3xl font-bold text-gray-900">Track Your Shipment</h1>
        <p className="text-gray-600 mt-2">Enter your tracking number to see real-time updates</p>
      </div>

      {/* Tracking Search */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1">
            <input
              type="text"
              placeholder="Enter tracking number (e.g., TRK-2024-001)"
              value={trackingNumber}
              onChange={(e) => setTrackingNumber(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <button
            onClick={handleTrackingSearch}
            className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2"
          >
            <Search className="h-4 w-4" />
            <span>Track</span>
          </button>
        </div>
      </div>

      {/* Shipment Details */}
      {selectedShipment && (
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-xl font-semibold text-gray-900">
                Shipment {selectedShipment.trackingNumber}
              </h2>
              <p className="text-gray-600">
                {selectedShipment.carrier} • {selectedShipment.transportMode}
              </p>
            </div>
            <div className="flex items-center space-x-2">
              <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(selectedShipment.status)}`}>
                {selectedShipment.status.replace('_', ' ')}
              </span>
              <QrCode className="h-5 w-5 text-gray-400 cursor-pointer hover:text-blue-600" />
            </div>
          </div>

          {/* Progress Timeline */}
          <div className="mb-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Shipment Progress</h3>
            <div className="relative">
              <div className="absolute left-4 top-0 bottom-0 w-0.5 bg-gray-300"></div>
              <div className="space-y-4">
                {selectedShipment.route.map((location, index) => {
                  const isCompleted = index <= selectedShipment.route.findIndex(l => l.id === selectedShipment.currentLocation.id);
                  const isCurrent = location.id === selectedShipment.currentLocation.id;
                  
                  return (
                    <div key={location.id} className="relative flex items-center">
                      <div className={`relative z-10 w-8 h-8 rounded-full flex items-center justify-center ${
                        isCompleted 
                          ? 'bg-green-500 text-white' 
                          : isCurrent 
                            ? 'bg-blue-500 text-white' 
                            : 'bg-gray-200 text-gray-600'
                      }`}>
                        {isCompleted && !isCurrent ? (
                          <CheckCircle className="h-4 w-4" />
                        ) : (
                          <span className="text-sm font-medium">{index + 1}</span>
                        )}
                      </div>
                      <div className="ml-4">
                        <h4 className="font-medium text-gray-900">{location.name}</h4>
                        <p className="text-sm text-gray-600">{location.address}</p>
                        {isCurrent && (
                          <p className="text-xs text-blue-600 font-medium mt-1">Current Location</p>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Delivery Information */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h3 className="text-lg font-medium text-gray-900">Delivery Information</h3>
              <div className="space-y-3">
                <div className="flex items-center space-x-2">
                  <Clock className="h-4 w-4 text-gray-400" />
                  <span className="text-sm text-gray-600">
                    ETA: {new Date(selectedShipment.estimatedDelivery).toLocaleString()}
                  </span>
                </div>
                <div className="flex items-center space-x-2">
                  <MapPin className="h-4 w-4 text-gray-400" />
                  <span className="text-sm text-gray-600">
                    Destination: {selectedShipment.destination.address}
                  </span>
                </div>
                {selectedShipment.deliveryPersonnel && (
                  <div className="flex items-center space-x-2">
                    <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center">
                      <span className="text-sm font-medium text-gray-600">
                        {selectedShipment.deliveryPersonnel.name.charAt(0)}
                      </span>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-900">
                        {selectedShipment.deliveryPersonnel.name}
                      </p>
                      <p className="text-xs text-gray-600">
                        {selectedShipment.deliveryPersonnel.phone}
                      </p>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Star className="h-3 w-3 text-yellow-400" />
                      <span className="text-xs text-gray-600">
                        {selectedShipment.deliveryPersonnel.rating}
                      </span>
                    </div>
                  </div>
                )}
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-lg font-medium text-gray-900">Package Details</h3>
              <div className="space-y-3">
                {selectedShipment.products.map((product) => (
                  <div key={product.id} className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                    <Package className="h-8 w-8 text-gray-400" />
                    <div>
                      <p className="font-medium text-gray-900">{product.name}</p>
                      <p className="text-sm text-gray-600">
                        Quantity: {product.quantity} • Origin: {product.origin}
                      </p>
                      <p className="text-xs text-gray-500">
                        Batch: {product.batchNumber}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Transparency Section */}
          <div className="mt-6 p-4 bg-blue-50 rounded-lg">
            <h3 className="text-lg font-medium text-blue-900 mb-2">Supply Chain Transparency</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
              <div>
                <p className="font-medium text-blue-900">Sustainability Score</p>
                <p className="text-blue-700">{selectedShipment.sustainabilityScore}/100</p>
              </div>
              <div>
                <p className="font-medium text-blue-900">Carbon Footprint</p>
                <p className="text-blue-700">
                  {selectedShipment.products.reduce((sum, p) => sum + p.co2Emissions, 0).toFixed(1)} kg CO₂
                </p>
              </div>
              <div>
                <p className="font-medium text-blue-900">Authenticity</p>
                <p className="text-blue-700">Blockchain Verified</p>
              </div>
            </div>
            <div className="mt-3 flex space-x-2">
              <button className="flex items-center space-x-1 text-blue-600 hover:text-blue-800">
                <Download className="h-4 w-4" />
                <span>Download Certificate</span>
              </button>
              <button className="flex items-center space-x-1 text-blue-600 hover:text-blue-800">
                <QrCode className="h-4 w-4" />
                <span>View QR Code</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Help Section */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <h3 className="text-lg font-medium text-gray-900 mb-4">Need Help?</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="text-center">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-3">
              <Package className="h-6 w-6 text-blue-600" />
            </div>
            <h4 className="font-medium text-gray-900">Track Another Package</h4>
            <p className="text-sm text-gray-600">Enter a different tracking number</p>
          </div>
          <div className="text-center">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-3">
              <MapPin className="h-6 w-6 text-green-600" />
            </div>
            <h4 className="font-medium text-gray-900">Update Delivery Address</h4>
            <p className="text-sm text-gray-600">Change your delivery location</p>
          </div>
          <div className="text-center">
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-3">
              <Clock className="h-6 w-6 text-purple-600" />
            </div>
            <h4 className="font-medium text-gray-900">Delivery Preferences</h4>
            <p className="text-sm text-gray-600">Set delivery time preferences</p>
          </div>
        </div>
      </div>
    </div>
  );
};