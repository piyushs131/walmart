import React, { useState } from 'react';
import { Search, Filter, Plus, Star, MapPin, Clock, DollarSign, TrendingUp, AlertTriangle, CheckCircle, Globe, Award, Download } from 'lucide-react';
import { Supplier } from '../../types';

interface SupplierManagementProps {
  suppliers: Supplier[];
}

export const SupplierManagement: React.FC<SupplierManagementProps> = ({ suppliers }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [selectedSupplier, setSelectedSupplier] = useState<Supplier | null>(null);
  const [showCertificationModal, setShowCertificationModal] = useState(false);

  const filteredSuppliers = suppliers.filter(supplier => {
    const matchesSearch = supplier.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = filterType === 'all' || 
      (filterType === 'international' && supplier.isInternational) ||
      (filterType === 'domestic' && !supplier.isInternational);
    return matchesSearch && matchesType;
  });

  const getRatingColor = (rating: number) => {
    if (rating >= 4.5) return 'text-green-600';
    if (rating >= 4.0) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getPerformanceColor = (score: number) => {
    if (score >= 90) return 'bg-green-100 text-green-800';
    if (score >= 75) return 'bg-yellow-100 text-yellow-800';
    return 'bg-red-100 text-red-800';
  };

  const handleViewCertifications = (supplier: Supplier) => {
    setSelectedSupplier(supplier);
    setShowCertificationModal(true);
  };

  const handleDownloadCertification = (certName: string) => {
    // Simulate certificate download
    const link = document.createElement('a');
    link.href = '#';
    link.download = `${certName.toLowerCase().replace(/\s+/g, '-')}.pdf`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    alert(`${certName} certificate download started`);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center space-y-4 sm:space-y-0">
        <h2 className="text-xl font-semibold text-gray-900">Supplier Management</h2>
        <button className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
          <Plus className="h-4 w-4" />
          <span>Add Supplier</span>
        </button>
      </div>

      {/* Search and Filters */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
          <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-4 sm:space-y-0 sm:space-x-4">
            <div className="relative w-full sm:w-auto">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <input
                type="text"
                placeholder="Search suppliers..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent w-full sm:w-64"
              />
            </div>
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent w-full sm:w-auto"
            >
              <option value="all">All Suppliers</option>
              <option value="domestic">Domestic</option>
              <option value="international">International</option>
            </select>
          </div>
        </div>
      </div>

      {/* Supplier Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
        {filteredSuppliers.map((supplier) => (
          <div
            key={supplier.id}
            className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-all duration-200 cursor-pointer border border-gray-200 hover:border-blue-300"
            onClick={() => setSelectedSupplier(supplier)}
          >
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <h3 className="text-lg font-medium text-gray-900 mb-1">{supplier.name}</h3>
                <div className="flex items-center space-x-2 mb-2">
                  <MapPin className="h-4 w-4 text-gray-400 flex-shrink-0" />
                  <span className="text-sm text-gray-600 truncate">{supplier.location.address}</span>
                  {supplier.isInternational && (
                    <Globe className="h-4 w-4 text-blue-500 flex-shrink-0" />
                  )}
                </div>
              </div>
              <div className="flex items-center space-x-1 flex-shrink-0">
                <Star className={`h-4 w-4 ${getRatingColor(supplier.rating)}`} />
                <span className={`text-sm font-medium ${getRatingColor(supplier.rating)}`}>
                  {supplier.rating}
                </span>
              </div>
            </div>

            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center space-x-2">
                  <Clock className="h-4 w-4 text-gray-400 flex-shrink-0" />
                  <div>
                    <p className="text-xs text-gray-500">Avg Delivery</p>
                    <p className="text-sm font-medium text-gray-900">{supplier.avgDeliveryTime}h</p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <DollarSign className="h-4 w-4 text-gray-400 flex-shrink-0" />
                  <div>
                    <p className="text-xs text-gray-500">Price/Unit</p>
                    <p className="text-sm font-medium text-gray-900">${supplier.pricePerUnit}</p>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-xs text-gray-500">On-Time Delivery</span>
                <span className={`px-2 py-1 text-xs font-medium rounded-full ${getPerformanceColor(supplier.performanceMetrics.onTimeDeliveryRate)}`}>
                  {supplier.performanceMetrics.onTimeDeliveryRate}%
                </span>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-xs text-gray-500">Quality Score</span>
                <span className={`px-2 py-1 text-xs font-medium rounded-full ${getPerformanceColor(supplier.performanceMetrics.qualityScore)}`}>
                  {supplier.performanceMetrics.qualityScore}
                </span>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-xs text-gray-500">Sustainability</span>
                <span className={`px-2 py-1 text-xs font-medium rounded-full ${getPerformanceColor(supplier.sustainability)}`}>
                  {supplier.sustainability}
                </span>
              </div>

              <div className="pt-3 border-t border-gray-200">
                <div className="flex items-center justify-between text-sm mb-2">
                  <span className="text-gray-500">Last Order:</span>
                  <span className="text-gray-900">
                    {new Date(supplier.lastOrderDate).toLocaleDateString()}
                  </span>
                </div>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    handleViewCertifications(supplier);
                  }}
                  className="w-full flex items-center justify-center space-x-2 px-3 py-2 bg-blue-600 text-white text-sm rounded-md hover:bg-blue-700 transition-colors"
                >
                  <Award className="h-4 w-4" />
                  <span>View Certifications</span>
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Supplier Details Modal */}
      {selectedSupplier && !showCertificationModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-semibold text-gray-900">{selectedSupplier.name}</h3>
                <button
                  onClick={() => setSelectedSupplier(null)}
                  className="text-gray-400 hover:text-gray-600 text-2xl"
                >
                  ×
                </button>
              </div>
            </div>

            <div className="p-6 space-y-6">
              {/* Contact Information */}
              <div>
                <h4 className="text-lg font-medium text-gray-900 mb-3">Contact Information</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-gray-500">Primary Contact</p>
                    <p className="font-medium">{selectedSupplier.contactInfo.primaryContact}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Email</p>
                    <p className="font-medium">{selectedSupplier.contactInfo.email}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Phone</p>
                    <p className="font-medium">{selectedSupplier.contactInfo.phone}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Website</p>
                    <p className="font-medium text-blue-600">{selectedSupplier.contactInfo.website}</p>
                  </div>
                </div>
              </div>

              {/* Performance Metrics */}
              <div>
                <h4 className="text-lg font-medium text-gray-900 mb-3">Performance Metrics</h4>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="text-center p-3 bg-gray-50 rounded-lg">
                    <p className="text-2xl font-bold text-blue-600">{selectedSupplier.performanceMetrics.totalOrders}</p>
                    <p className="text-sm text-gray-600">Total Orders</p>
                  </div>
                  <div className="text-center p-3 bg-gray-50 rounded-lg">
                    <p className="text-2xl font-bold text-green-600">{selectedSupplier.performanceMetrics.onTimeDeliveryRate}%</p>
                    <p className="text-sm text-gray-600">On-Time Delivery</p>
                  </div>
                  <div className="text-center p-3 bg-gray-50 rounded-lg">
                    <p className="text-2xl font-bold text-purple-600">{selectedSupplier.performanceMetrics.qualityScore}</p>
                    <p className="text-sm text-gray-600">Quality Score</p>
                  </div>
                  <div className="text-center p-3 bg-gray-50 rounded-lg">
                    <p className="text-2xl font-bold text-orange-600">{selectedSupplier.performanceMetrics.riskScore}</p>
                    <p className="text-sm text-gray-600">Risk Score</p>
                  </div>
                </div>
              </div>

              {/* Certifications */}
              <div>
                <h4 className="text-lg font-medium text-gray-900 mb-3">Certifications</h4>
                <div className="space-y-2">
                  {selectedSupplier.certifications.map((cert) => (
                    <div key={cert.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div>
                        <p className="font-medium">{cert.name}</p>
                        <p className="text-sm text-gray-600">Issued by {cert.issuingBody}</p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                          cert.status === 'valid' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                        }`}>
                          {cert.status}
                        </span>
                        <span className="text-sm text-gray-500">
                          Expires: {new Date(cert.expiryDate).toLocaleDateString()}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-4 pt-4 border-t border-gray-200">
                <button className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                  Create Purchase Order
                </button>
                <button className="flex-1 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors">
                  View Order History
                </button>
                <button className="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
                  Contact Supplier
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Certification Modal */}
      {showCertificationModal && selectedSupplier && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-2xl w-full max-h-[80vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-semibold text-gray-900">
                  {selectedSupplier.name} - Certifications
                </h3>
                <button
                  onClick={() => setShowCertificationModal(false)}
                  className="text-gray-400 hover:text-gray-600 text-2xl"
                >
                  ×
                </button>
              </div>
            </div>

            <div className="p-6">
              <div className="space-y-4">
                {selectedSupplier.certifications.map((cert) => (
                  <div key={cert.id} className="border border-gray-200 rounded-lg p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-2">
                          <Award className="h-5 w-5 text-blue-600" />
                          <h4 className="font-medium text-gray-900">{cert.name}</h4>
                          <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                            cert.status === 'valid' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                          }`}>
                            {cert.status}
                          </span>
                        </div>
                        <div className="space-y-1 text-sm text-gray-600">
                          <p><span className="font-medium">Issuing Body:</span> {cert.issuingBody}</p>
                          <p><span className="font-medium">Issue Date:</span> {new Date(cert.issueDate).toLocaleDateString()}</p>
                          <p><span className="font-medium">Expiry Date:</span> {new Date(cert.expiryDate).toLocaleDateString()}</p>
                        </div>
                      </div>
                      <button
                        onClick={() => handleDownloadCertification(cert.name)}
                        className="flex items-center space-x-1 px-3 py-1 bg-blue-600 text-white text-sm rounded-md hover:bg-blue-700 transition-colors"
                      >
                        <Download className="h-4 w-4" />
                        <span>Download</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-6 flex space-x-3">
                <button 
                  onClick={() => setShowCertificationModal(false)}
                  className="flex-1 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
                >
                  Close
                </button>
                <button className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                  Download All Certificates
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};