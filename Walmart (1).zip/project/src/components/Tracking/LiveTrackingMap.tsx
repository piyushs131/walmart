import React, { useState, useEffect } from 'react';
import { MapPin, Truck, Clock, Route } from 'lucide-react';
import { Shipment, DeliveryPersonnel } from '../../types';

interface LiveTrackingMapProps {
  shipments: Shipment[];
}

export const LiveTrackingMap: React.FC<LiveTrackingMapProps> = ({ shipments }) => {
  const [selectedShipment, setSelectedShipment] = useState<Shipment | null>(null);
  const [livePositions, setLivePositions] = useState<{[key: string]: {lat: number, lng: number}}>({});

  useEffect(() => {
    // Simulate real-time position updates
    const interval = setInterval(() => {
      const newPositions: {[key: string]: {lat: number, lng: number}} = {};
      shipments.forEach(shipment => {
        if (shipment.status === 'in_transit' || shipment.status === 'out_for_delivery') {
          const currentPos = livePositions[shipment.id] || shipment.currentLocation.coordinates;
          // Simulate movement towards destination
          const destPos = shipment.destination.coordinates;
          const progress = 0.001; // Small movement per update
          
          newPositions[shipment.id] = {
            lat: currentPos.lat + (destPos.lat - currentPos.lat) * progress,
            lng: currentPos.lng + (destPos.lng - currentPos.lng) * progress
          };
        }
      });
      setLivePositions(prev => ({ ...prev, ...newPositions }));
    }, 3000);

    return () => clearInterval(interval);
  }, [shipments, livePositions]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'in_transit': return 'bg-blue-500';
      case 'out_for_delivery': return 'bg-green-500';
      case 'delayed': return 'bg-red-500';
      case 'delivered': return 'bg-gray-500';
      default: return 'bg-yellow-500';
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-xl font-semibold text-gray-900 mb-6">Live Tracking</h2>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Map Placeholder */}
        <div className="lg:col-span-2">
          <div className="relative bg-gray-100 rounded-lg h-96 flex items-center justify-center">
            <div className="text-center">
              <MapPin className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500">Interactive Map</p>
              <p className="text-sm text-gray-400">Real-time tracking visualization</p>
            </div>
            
            {/* Simulated map markers */}
            <div className="absolute inset-0 p-4">
              {shipments.map((shipment, index) => (
                <div
                  key={shipment.id}
                  className={`absolute w-4 h-4 rounded-full ${getStatusColor(shipment.status)} cursor-pointer hover:scale-110 transition-transform`}
                  style={{
                    left: `${20 + index * 15}%`,
                    top: `${30 + index * 10}%`
                  }}
                  onClick={() => setSelectedShipment(shipment)}
                />
              ))}
            </div>
          </div>
        </div>

        {/* Shipment Details */}
        <div className="space-y-4">
          <h3 className="text-lg font-medium text-gray-900">Active Shipments</h3>
          <div className="space-y-3">
            {shipments.map((shipment) => (
              <div
                key={shipment.id}
                className={`p-4 rounded-lg border cursor-pointer transition-all ${
                  selectedShipment?.id === shipment.id
                    ? 'border-blue-500 bg-blue-50'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
                onClick={() => setSelectedShipment(shipment)}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-gray-900">
                    {shipment.trackingNumber}
                  </span>
                  <span className={`px-2 py-1 text-xs font-medium rounded-full text-white ${getStatusColor(shipment.status)}`}>
                    {shipment.status.replace('_', ' ')}
                  </span>
                </div>
                
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Route className="h-4 w-4 text-gray-400" />
                    <span className="text-sm text-gray-600">
                      {shipment.origin.name} → {shipment.destination.name}
                    </span>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Clock className="h-4 w-4 text-gray-400" />
                    <span className="text-sm text-gray-600">
                      ETA: {new Date(shipment.estimatedDelivery).toLocaleString()}
                    </span>
                  </div>
                  
                  {shipment.deliveryPersonnel && (
                    <div className="flex items-center space-x-2">
                      <Truck className="h-4 w-4 text-gray-400" />
                      <span className="text-sm text-gray-600">
                        {shipment.deliveryPersonnel.name} - {shipment.deliveryPersonnel.vehicleNumber}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Selected Shipment Details */}
      {selectedShipment && (
        <div className="mt-6 bg-gray-50 rounded-lg p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">
            Shipment Details - {selectedShipment.trackingNumber}
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div>
              <h4 className="font-medium text-gray-900 mb-2">Products</h4>
              <ul className="space-y-1">
                {selectedShipment.products.map((product) => (
                  <li key={product.id} className="text-sm text-gray-600">
                    {product.name} (Qty: {product.quantity})
                  </li>
                ))}
              </ul>
            </div>
            
            <div>
              <h4 className="font-medium text-gray-900 mb-2">Route Information</h4>
              <div className="space-y-1">
                <p className="text-sm text-gray-600">
                  <span className="font-medium">Carrier:</span> {selectedShipment.carrier}
                </p>
                <p className="text-sm text-gray-600">
                  <span className="font-medium">Transport:</span> {selectedShipment.transportMode}
                </p>
                <p className="text-sm text-gray-600">
                  <span className="font-medium">Priority:</span> {selectedShipment.priority}
                </p>
              </div>
            </div>
            
            <div>
              <h4 className="font-medium text-gray-900 mb-2">Sustainability</h4>
              <div className="space-y-1">
                <p className="text-sm text-gray-600">
                  <span className="font-medium">Score:</span> {selectedShipment.sustainabilityScore}/100
                </p>
                <p className="text-sm text-gray-600">
                  <span className="font-medium">Total Cost:</span> ${selectedShipment.totalCost}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};