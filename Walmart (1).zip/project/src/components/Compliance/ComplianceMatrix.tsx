import React, { useState } from 'react';
import { Shield, CheckCircle, XCircle, AlertTriangle, Clock, FileText, Download, ExternalLink } from 'lucide-react';
import { Product } from '../../types';

interface ComplianceMatrixProps {
  products: Product[];
}

export const ComplianceMatrix: React.FC<ComplianceMatrixProps> = ({ products }) => {
  const [showDocumentModal, setShowDocumentModal] = useState(false);
  const [selectedDocument, setSelectedDocument] = useState<string | null>(null);

  const complianceStats = products.reduce((acc, product) => {
    acc[product.complianceStatus] = (acc[product.complianceStatus] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const getComplianceIcon = (status: string) => {
    switch (status) {
      case 'compliant': return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'non_compliant': return <XCircle className="h-5 w-5 text-red-500" />;
      case 'pending_review': return <AlertTriangle className="h-5 w-5 text-yellow-500" />;
      default: return <Clock className="h-5 w-5 text-gray-500" />;
    }
  };

  const getComplianceColor = (status: string) => {
    switch (status) {
      case 'compliant': return 'bg-green-50 border-green-200';
      case 'non_compliant': return 'bg-red-50 border-red-200';
      case 'pending_review': return 'bg-yellow-50 border-yellow-200';
      default: return 'bg-gray-50 border-gray-200';
    }
  };

  const handleViewDocs = (docType: string) => {
    setSelectedDocument(docType);
    setShowDocumentModal(true);
  };

  const handleDownloadCertificate = (certType: string) => {
    // Simulate certificate download
    const link = document.createElement('a');
    link.href = '#';
    link.download = `${certType.toLowerCase().replace(/\s+/g, '-')}-certificate.pdf`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    // Show success message
    alert(`${certType} certificate download started`);
  };

  const complianceRequirements = [
    {
      id: 'hazmat',
      name: 'Hazardous Materials',
      description: 'UN classification, safety data sheets, proper packaging',
      categories: ['hazardous'],
      critical: true,
      documents: ['UN Classification Certificate', 'Safety Data Sheet', 'Packaging Compliance']
    },
    {
      id: 'pharma',
      name: 'Pharmaceutical',
      description: 'FDA approval, temperature control, expiration tracking',
      categories: ['pharmaceuticals'],
      critical: true,
      documents: ['FDA Approval', 'GMP Certificate', 'Temperature Validation']
    },
    {
      id: 'food',
      name: 'Food Safety',
      description: 'HACCP compliance, organic certification, allergen labeling',
      categories: ['groceries', 'perishables'],
      critical: false,
      documents: ['HACCP Certificate', 'Organic Certification', 'Allergen Declaration']
    },
    {
      id: 'customs',
      name: 'Customs & Trade',
      description: 'Import/export documentation, tariff classification',
      categories: ['all'],
      critical: false,
      documents: ['Import License', 'Export Declaration', 'Tariff Classification']
    }
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold text-gray-900">Compliance Management</h2>
        <div className="flex items-center space-x-2">
          <Shield className="h-5 w-5 text-blue-600" />
          <span className="text-sm text-gray-600">Regulatory Compliance Dashboard</span>
        </div>
      </div>

      {/* Compliance Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {Object.entries(complianceStats).map(([status, count]) => (
          <div key={status} className={`p-4 rounded-lg border ${getComplianceColor(status)}`}>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-900 capitalize">
                  {status.replace('_', ' ')}
                </p>
                <p className="text-2xl font-bold text-gray-900">{count}</p>
              </div>
              {getComplianceIcon(status)}
            </div>
          </div>
        ))}
      </div>

      {/* Compliance Requirements */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <h3 className="text-lg font-medium text-gray-900 mb-4">Compliance Requirements</h3>
        <div className="space-y-4">
          {complianceRequirements.map((req) => (
            <div key={req.id} className="border border-gray-200 rounded-lg p-4">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center space-x-2">
                    <h4 className="font-medium text-gray-900">{req.name}</h4>
                    {req.critical && (
                      <span className="px-2 py-1 bg-red-100 text-red-800 text-xs font-medium rounded-full">
                        Critical
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-gray-600 mt-1">{req.description}</p>
                  <div className="flex items-center space-x-2 mt-2">
                    <span className="text-xs text-gray-500">Applies to:</span>
                    <div className="flex space-x-1">
                      {req.categories.map((category) => (
                        <span key={category} className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded">
                          {category}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <button 
                    onClick={() => handleViewDocs(req.name)}
                    className="flex items-center space-x-1 px-3 py-1 bg-blue-600 text-white text-sm rounded-md hover:bg-blue-700 transition-colors"
                  >
                    <FileText className="h-4 w-4" />
                    <span>View Docs</span>
                  </button>
                  <button 
                    onClick={() => handleDownloadCertificate(req.name)}
                    className="flex items-center space-x-1 px-3 py-1 bg-green-600 text-white text-sm rounded-md hover:bg-green-700 transition-colors"
                  >
                    <Download className="h-4 w-4" />
                    <span>Certificate</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Non-Compliant Items */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <h3 className="text-lg font-medium text-gray-900 mb-4">Items Requiring Attention</h3>
        <div className="space-y-3">
          {products
            .filter(product => product.complianceStatus !== 'compliant')
            .map((product) => (
              <div key={product.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  {getComplianceIcon(product.complianceStatus)}
                  <div>
                    <p className="font-medium text-gray-900">{product.name}</p>
                    <p className="text-sm text-gray-600">
                      Batch: {product.batchNumber} • Category: {product.category}
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-gray-500 capitalize">
                    {product.complianceStatus.replace('_', ' ')}
                  </span>
                  <button className="px-3 py-1 bg-blue-600 text-white text-sm rounded hover:bg-blue-700 transition-colors">
                    Review
                  </button>
                </div>
              </div>
            ))}
        </div>
      </div>

      {/* Document Modal */}
      {showDocumentModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-2xl w-full max-h-[80vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-semibold text-gray-900">
                  {selectedDocument} Documentation
                </h3>
                <button
                  onClick={() => setShowDocumentModal(false)}
                  className="text-gray-400 hover:text-gray-600 text-2xl"
                >
                  ×
                </button>
              </div>
            </div>

            <div className="p-6">
              <div className="space-y-4">
                {complianceRequirements
                  .find(req => req.name === selectedDocument)
                  ?.documents.map((doc, index) => (
                    <div key={index} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <FileText className="h-5 w-5 text-blue-600" />
                        <div>
                          <p className="font-medium text-gray-900">{doc}</p>
                          <p className="text-sm text-gray-600">Last updated: Jan 15, 2024</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <span className="px-2 py-1 bg-green-100 text-green-800 text-xs font-medium rounded-full">
                          Valid
                        </span>
                        <button className="p-2 text-gray-400 hover:text-blue-600 transition-colors">
                          <ExternalLink className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  ))}
              </div>

              <div className="mt-6 flex space-x-3">
                <button 
                  onClick={() => setShowDocumentModal(false)}
                  className="flex-1 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
                >
                  Close
                </button>
                <button className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                  Download All
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};