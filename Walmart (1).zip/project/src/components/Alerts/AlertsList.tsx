import React from 'react';
import { AlertTriangle, Package, Clock, ExternalLink, CheckCircle, XCircle } from 'lucide-react';
import { InventoryAlert, RiskAlert } from '../../types';

interface AlertsListProps {
  title: string;
  alerts: (InventoryAlert | RiskAlert)[];
  type: 'inventory' | 'risk';
}

export const AlertsList: React.FC<AlertsListProps> = ({ title, alerts, type }) => {
  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case 'critical': return 'text-red-700 bg-red-50 border-red-200';
      case 'high': return 'text-amber-700 bg-amber-50 border-amber-200';
      case 'medium': return 'text-yellow-700 bg-yellow-50 border-yellow-200';
      default: return 'text-slate-700 bg-slate-50 border-slate-200';
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'text-red-700 bg-red-50 border-red-200';
      case 'high': return 'text-amber-700 bg-amber-50 border-amber-200';
      case 'medium': return 'text-yellow-700 bg-yellow-50 border-yellow-200';
      default: return 'text-slate-700 bg-slate-50 border-slate-200';
    }
  };

  const getAlertIcon = (urgency: string, severity?: string) => {
    const level = urgency || severity;
    switch (level) {
      case 'critical':
        return <XCircle className="h-5 w-5 text-red-500" />;
      case 'high':
        return <AlertTriangle className="h-5 w-5 text-amber-500" />;
      case 'medium':
        return <AlertTriangle className="h-5 w-5 text-yellow-500" />;
      default:
        return <CheckCircle className="h-5 w-5 text-slate-500" />;
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-lg font-semibold text-slate-900">{title}</h3>
        <div className="flex items-center space-x-2">
          <span className="text-sm text-slate-500">{alerts.length} active</span>
          <button className="text-sm text-blue-600 hover:text-blue-800 font-medium">
            View All
          </button>
        </div>
      </div>
      
      <div className="space-y-4">
        {alerts.slice(0, 5).map((alert) => (
          <div key={alert.id} className="border border-slate-200 rounded-lg p-4 hover:shadow-sm transition-all duration-200 hover:border-slate-300">
            <div className="flex items-start justify-between">
              <div className="flex items-start space-x-3 flex-1">
                <div className="p-2 bg-slate-50 rounded-lg flex-shrink-0">
                  {type === 'inventory' ? (
                    <Package className="h-4 w-4 text-blue-600" />
                  ) : (
                    getAlertIcon('', (alert as RiskAlert).severity)
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  {type === 'inventory' ? (
                    <div>
                      <h4 className="font-medium text-slate-900 mb-1">
                        {(alert as InventoryAlert).productName}
                      </h4>
                      <p className="text-sm text-slate-600 mb-2">
                        {(alert as InventoryAlert).recommendedAction}
                      </p>
                      <div className="flex items-center space-x-4 text-xs text-slate-500">
                        <span>Current: {(alert as InventoryAlert).currentStock}</span>
                        {(alert as InventoryAlert).threshold && (
                          <span>Threshold: {(alert as InventoryAlert).threshold}</span>
                        )}
                      </div>
                    </div>
                  ) : (
                    <div>
                      <h4 className="font-medium text-slate-900 mb-1">
                        {(alert as RiskAlert).type.charAt(0).toUpperCase() + (alert as RiskAlert).type.slice(1)} Risk
                      </h4>
                      <p className="text-sm text-slate-600 mb-2">
                        {(alert as RiskAlert).message}
                      </p>
                      <div className="flex items-center space-x-2 text-xs text-slate-500">
                        <Clock className="h-3 w-3" />
                        <span>
                          {new Date((alert as RiskAlert).timestamp).toLocaleString()}
                        </span>
                      </div>
                    </div>
                  )}
                </div>
              </div>
              <div className="flex items-center space-x-2 flex-shrink-0">
                <span className={`px-2 py-1 text-xs font-medium rounded-full border ${
                  type === 'inventory' 
                    ? getUrgencyColor((alert as InventoryAlert).urgency)
                    : getSeverityColor((alert as RiskAlert).severity)
                }`}>
                  {type === 'inventory' ? (alert as InventoryAlert).urgency : (alert as RiskAlert).severity}
                </span>
                <button className="p-1 text-slate-400 hover:text-blue-600 transition-colors">
                  <ExternalLink className="h-4 w-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {alerts.length === 0 && (
        <div className="text-center py-8">
          <CheckCircle className="h-12 w-12 text-emerald-500 mx-auto mb-3" />
          <p className="text-slate-600 font-medium">No active alerts</p>
          <p className="text-sm text-slate-500">All systems are operating normally</p>
        </div>
      )}
    </div>
  );
};