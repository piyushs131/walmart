import React from 'react';
import { MapPin, Users, Package, AlertTriangle, TrendingUp } from 'lucide-react';
import { Warehouse } from '../../types';

interface WarehouseGridProps {
  warehouses: Warehouse[];
}

export const WarehouseGrid: React.FC<WarehouseGridProps> = ({ warehouses }) => {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-500';
      case 'maintenance': return 'bg-yellow-500';
      case 'closed': return 'bg-red-500';
      case 'limited_capacity': return 'bg-orange-500';
      default: return 'bg-gray-500';
    }
  };

  const getCapacityPercentage = (warehouse: Warehouse) => {
    return Math.round((warehouse.currentLoad / warehouse.capacity) * 100);
  };

  const getCapacityColor = (percentage: number) => {
    if (percentage >= 90) return 'bg-red-500';
    if (percentage >= 75) return 'bg-yellow-500';
    return 'bg-green-500';
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold text-gray-900">Warehouse Overview</h2>
        <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
          Add Warehouse
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {warehouses.map((warehouse) => {
          const capacityPercentage = getCapacityPercentage(warehouse);
          
          return (
            <div key={warehouse.id} className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-medium text-gray-900">{warehouse.name}</h3>
                <div className="flex items-center space-x-2">
                  <div className={`w-3 h-3 rounded-full ${getStatusColor(warehouse.operationalStatus)}`}></div>
                  <span className="text-sm text-gray-600 capitalize">
                    {warehouse.operationalStatus.replace('_', ' ')}
                  </span>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-center space-x-2">
                  <MapPin className="h-4 w-4 text-gray-400" />
                  <span className="text-sm text-gray-600">{warehouse.location.address}</span>
                </div>

                <div className="flex items-center space-x-2">
                  <Users className="h-4 w-4 text-gray-400" />
                  <span className="text-sm text-gray-600">Manager: {warehouse.manager}</span>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-gray-900">Capacity Usage</span>
                    <span className="text-sm text-gray-600">{capacityPercentage}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className={`h-2 rounded-full transition-all duration-300 ${getCapacityColor(capacityPercentage)}`}
                      style={{ width: `${capacityPercentage}%` }}
                    ></div>
                  </div>
                  <div className="flex justify-between text-xs text-gray-500">
                    <span>{warehouse.currentLoad.toLocaleString()} units</span>
                    <span>{warehouse.capacity.toLocaleString()} max</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center">
                    <div className="flex items-center justify-center space-x-1">
                      <Package className="h-4 w-4 text-blue-600" />
                      <span className="text-sm font-medium text-gray-900">
                        {warehouse.products.length}
                      </span>
                    </div>
                    <span className="text-xs text-gray-500">Product Types</span>
                  </div>
                  <div className="text-center">
                    <div className="flex items-center justify-center space-x-1">
                      <AlertTriangle className="h-4 w-4 text-red-600" />
                      <span className="text-sm font-medium text-gray-900">
                        {warehouse.alertsCount}
                      </span>
                    </div>
                    <span className="text-xs text-gray-500">Active Alerts</span>
                  </div>
                </div>

                <div className="pt-4 border-t border-gray-200">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-500">Last Check:</span>
                    <span className="text-gray-900">
                      {new Date(warehouse.lastInventoryCheck).toLocaleDateString()}
                    </span>
                  </div>
                </div>

                <div className="flex space-x-2">
                  <button className="flex-1 px-3 py-2 bg-blue-600 text-white text-sm rounded-md hover:bg-blue-700 transition-colors">
                    View Details
                  </button>
                  <button className="flex-1 px-3 py-2 bg-gray-100 text-gray-700 text-sm rounded-md hover:bg-gray-200 transition-colors">
                    Manage
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};