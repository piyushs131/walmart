import { 
  Product, Shipment, Location, Warehouse, InventoryAlert, Analytics, 
  DeliveryPersonnel, RiskAlert, Document, Supplier, PurchaseOrder,
  DemandForecast, OptimizationSuggestion, SupplierMetrics, User,
  WarehouseZone, Equipment, Certification, ContactInfo
} from '../types';

export const mockLocations: Location[] = [
  {
    id: '1',
    name: 'Seattle Distribution Center',
    address: '1234 Industrial Way, Seattle, WA 98101',
    coordinates: { lat: 47.6062, lng: -122.3321 },
    type: 'distribution_center',
    capacity: 100000,
    currentLoad: 75000,
    temperatureControlled: true,
    hazmatCertified: true,
    securityLevel: 'high'
  },
  {
    id: '2',
    name: 'Portland Cold Storage',
    address: '5678 Logistics Blvd, Portland, OR 97201',
    coordinates: { lat: 45.5152, lng: -122.6784 },
    type: 'warehouse',
    capacity: 50000,
    currentLoad: 42000,
    temperatureControlled: true,
    hazmatCertified: false,
    securityLevel: 'standard'
  },
  {
    id: '3',
    name: 'San Francisco Pharma Hub',
    address: '9012 Bay Area Dr, San Francisco, CA 94102',
    coordinates: { lat: 37.7749, lng: -122.4194 },
    type: 'warehouse',
    capacity: 80000,
    currentLoad: 55000,
    temperatureControlled: true,
    hazmatCertified: true,
    securityLevel: 'maximum'
  },
  {
    id: '4',
    name: 'Los Angeles International Port',
    address: '1111 Harbor Blvd, Los Angeles, CA 90731',
    coordinates: { lat: 34.0522, lng: -118.2437 },
    type: 'port',
    capacity: 200000,
    currentLoad: 150000,
    temperatureControlled: false,
    hazmatCertified: true,
    securityLevel: 'high'
  },
  {
    id: '5',
    name: 'Customer Delivery Point',
    address: '123 Main St, Portland, OR 97205',
    coordinates: { lat: 45.5230, lng: -122.6765 },
    type: 'customer',
    securityLevel: 'standard'
  }
];

export const mockSuppliers: Supplier[] = [
  {
    id: '1',
    name: 'Washington Organic Farms',
    location: mockLocations[0],
    rating: 4.9,
    avgDeliveryTime: 24,
    pricePerUnit: 2.50,
    capacity: 10000,
    sustainability: 95,
    contactInfo: {
      primaryContact: 'John Anderson',
      email: 'john@waorganic.com',
      phone: '+1-206-555-0123',
      address: '1234 Farm Road, Yakima, WA 98901',
      website: 'www.waorganicfarms.com'
    },
    certifications: [
      {
        id: 'cert1',
        name: 'USDA Organic',
        issuingBody: 'USDA',
        issueDate: '2023-01-15',
        expiryDate: '2025-01-15',
        status: 'valid',
        documentUrl: '/docs/usda-organic.pdf'
      }
    ],
    paymentTerms: 'Net 30',
    minimumOrder: 500,
    isInternational: false,
    performanceMetrics: {
      supplierId: '1',
      supplierName: 'Washington Organic Farms',
      totalOrders: 156,
      onTimeDeliveryRate: 98.5,
      qualityScore: 96,
      averageLeadTime: 24,
      costPerformance: 92,
      sustainabilityScore: 95,
      complianceScore: 98,
      riskScore: 12
    },
    products: ['1', '4'],
    lastOrderDate: '2024-01-10',
    totalOrders: 156,
    onTimeDeliveryRate: 98.5,
    qualityScore: 96,
    complianceStatus: 'compliant'
  },
  {
    id: '2',
    name: 'TechCorp International',
    location: mockLocations[3],
    rating: 4.6,
    avgDeliveryTime: 72,
    pricePerUnit: 15.99,
    capacity: 5000,
    sustainability: 70,
    contactInfo: {
      primaryContact: 'Sarah Chen',
      email: 'sarah@techcorp.com',
      phone: '+86-21-5555-0123',
      address: '789 Tech Park, Shanghai, China',
      website: 'www.techcorp.com'
    },
    certifications: [
      {
        id: 'cert2',
        name: 'ISO 9001',
        issuingBody: 'ISO',
        issueDate: '2023-06-01',
        expiryDate: '2026-06-01',
        status: 'valid',
        documentUrl: '/docs/iso-9001.pdf'
      }
    ],
    paymentTerms: 'Net 45',
    minimumOrder: 100,
    isInternational: true,
    customsDocuments: [
      {
        id: 'doc1',
        type: 'customs_declaration',
        name: 'Import Declaration',
        status: 'valid',
        expiryDate: '2024-12-31',
        downloadUrl: '/docs/import-declaration.pdf',
        uploadedBy: 'system',
        uploadedDate: '2024-01-01',
        version: 1
      }
    ],
    performanceMetrics: {
      supplierId: '2',
      supplierName: 'TechCorp International',
      totalOrders: 89,
      onTimeDeliveryRate: 85.2,
      qualityScore: 88,
      averageLeadTime: 72,
      costPerformance: 78,
      sustainabilityScore: 70,
      complianceScore: 92,
      riskScore: 35
    },
    products: ['2'],
    lastOrderDate: '2024-01-08',
    totalOrders: 89,
    onTimeDeliveryRate: 85.2,
    qualityScore: 88,
    complianceStatus: 'compliant'
  },
  {
    id: '3',
    name: 'MedSupply Pharmaceuticals',
    location: mockLocations[2],
    rating: 4.8,
    avgDeliveryTime: 48,
    pricePerUnit: 89.99,
    capacity: 2000,
    sustainability: 85,
    contactInfo: {
      primaryContact: 'Dr. Michael Roberts',
      email: 'michael@medsupply.com',
      phone: '+1-415-555-0123',
      address: '456 Pharma Way, South San Francisco, CA 94080',
      website: 'www.medsupply.com'
    },
    certifications: [
      {
        id: 'cert3',
        name: 'FDA GMP',
        issuingBody: 'FDA',
        issueDate: '2023-03-15',
        expiryDate: '2025-03-15',
        status: 'valid',
        documentUrl: '/docs/fda-gmp.pdf'
      }
    ],
    paymentTerms: 'Net 15',
    minimumOrder: 50,
    isInternational: false,
    performanceMetrics: {
      supplierId: '3',
      supplierName: 'MedSupply Pharmaceuticals',
      totalOrders: 234,
      onTimeDeliveryRate: 96.8,
      qualityScore: 98,
      averageLeadTime: 48,
      costPerformance: 85,
      sustainabilityScore: 85,
      complianceScore: 99,
      riskScore: 8
    },
    products: ['3'],
    lastOrderDate: '2024-01-12',
    totalOrders: 234,
    onTimeDeliveryRate: 96.8,
    qualityScore: 98,
    complianceStatus: 'compliant'
  }
];

export const mockProducts: Product[] = [
  {
    id: '1',
    name: 'Organic Apples - Honeycrisp',
    category: 'groceries',
    origin: 'Washington Organic Farms',
    batchNumber: 'WAF-HC-2024-001',
    quantity: 5000,
    price: 2.99,
    expiryDate: '2024-02-15',
    sustainabilityScore: 95,
    authenticity: 'verified',
    complianceStatus: 'compliant',
    currentLocation: mockLocations[0],
    warehouse: 'Seattle Distribution Center',
    supplier: 'Washington Organic Farms',
    riskScore: 15,
    co2Emissions: 0.5,
    lastUpdated: '2024-01-15T10:30:00Z',
    fifoDate: '2024-01-10T08:00:00Z',
    reorderPoint: 1000,
    maxStock: 8000,
    minStock: 500,
    handlingInstructions: 'Keep refrigerated at 32-35°F',
    temperatureRange: { min: 0, max: 4, unit: 'C' },
    barcode: '1234567890123',
    rfidTag: 'RF001234'
  },
  {
    id: '2',
    name: 'Lithium Ion Batteries - 18650',
    category: 'hazardous',
    origin: 'TechCorp International',
    batchNumber: 'TC-LI-2024-001',
    quantity: 1000,
    price: 15.99,
    sustainabilityScore: 60,
    authenticity: 'verified',
    complianceStatus: 'compliant',
    currentLocation: mockLocations[1],
    warehouse: 'Portland Cold Storage',
    supplier: 'TechCorp International',
    riskScore: 45,
    co2Emissions: 2.1,
    lastUpdated: '2024-01-15T11:00:00Z',
    fifoDate: '2024-01-08T14:00:00Z',
    reorderPoint: 200,
    maxStock: 2000,
    minStock: 100,
    handlingInstructions: 'Handle with care - Hazmat Class 9',
    hazardClass: 'class_9',
    barcode: '2345678901234'
  },
  {
    id: '3',
    name: 'Insulin Vials - Rapid Acting',
    category: 'pharmaceuticals',
    origin: 'MedSupply Pharmaceuticals',
    batchNumber: 'MED-INS-2024-001',
    quantity: 500,
    price: 89.99,
    expiryDate: '2024-06-30',
    sustainabilityScore: 75,
    authenticity: 'verified',
    complianceStatus: 'compliant',
    currentLocation: mockLocations[2],
    warehouse: 'San Francisco Pharma Hub',
    supplier: 'MedSupply Pharmaceuticals',
    riskScore: 25,
    co2Emissions: 1.2,
    lastUpdated: '2024-01-15T09:45:00Z',
    fifoDate: '2024-01-12T10:00:00Z',
    reorderPoint: 100,
    maxStock: 1000,
    minStock: 50,
    handlingInstructions: 'Refrigerate 2-8°C. Do not freeze.',
    temperatureRange: { min: 2, max: 8, unit: 'C' },
    barcode: '3456789012345'
  },
  {
    id: '4',
    name: 'Organic Spinach - Baby Leaves',
    category: 'perishables',
    origin: 'Washington Organic Farms',
    batchNumber: 'WAF-SP-2024-002',
    quantity: 200,
    price: 4.99,
    expiryDate: '2024-01-20',
    sustainabilityScore: 92,
    authenticity: 'verified',
    complianceStatus: 'compliant',
    currentLocation: mockLocations[0],
    warehouse: 'Seattle Distribution Center',
    supplier: 'Washington Organic Farms',
    riskScore: 35,
    co2Emissions: 0.3,
    lastUpdated: '2024-01-15T12:00:00Z',
    fifoDate: '2024-01-14T06:00:00Z',
    reorderPoint: 500,
    maxStock: 2000,
    minStock: 100,
    handlingInstructions: 'Keep refrigerated. High turnover required.',
    temperatureRange: { min: 0, max: 4, unit: 'C' },
    barcode: '4567890123456'
  }
];

export const mockDeliveryPersonnel: DeliveryPersonnel[] = [
  {
    id: '1',
    name: 'John Smith',
    phone: '+1-555-0123',
    vehicleNumber: 'TRK-001',
    currentLocation: { lat: 45.5200, lng: -122.6750 },
    rating: 4.8,
    certifications: ['Hazmat', 'Food Safety'],
    hazmatCertified: true,
    activeDeliveries: ['1', '3'],
    maxCapacity: 5000,
    currentLoad: 3200
  },
  {
    id: '2',
    name: 'Sarah Johnson',
    phone: '+1-555-0124',
    vehicleNumber: 'VAN-002',
    currentLocation: { lat: 47.6100, lng: -122.3300 },
    rating: 4.9,
    certifications: ['Temperature Control', 'Pharmaceutical'],
    hazmatCertified: false,
    activeDeliveries: ['2'],
    maxCapacity: 2000,
    currentLoad: 800
  },
  {
    id: '3',
    name: 'Mike Rodriguez',
    phone: '+1-555-0125',
    vehicleNumber: 'TRK-003',
    currentLocation: { lat: 37.7849, lng: -122.4094 },
    rating: 4.7,
    certifications: ['Hazmat', 'Heavy Lifting'],
    hazmatCertified: true,
    activeDeliveries: [],
    maxCapacity: 8000,
    currentLoad: 0
  }
];

export const mockPurchaseOrders: PurchaseOrder[] = [
  {
    id: 'PO-2024-001',
    supplierId: '1',
    supplierName: 'Washington Organic Farms',
    products: [
      {
        productId: '1',
        productName: 'Organic Apples - Honeycrisp',
        quantity: 2000,
        unitPrice: 2.50,
        totalPrice: 5000
      }
    ],
    totalAmount: 5000,
    status: 'confirmed',
    createdDate: '2024-01-10T09:00:00Z',
    expectedDelivery: '2024-01-17T14:00:00Z',
    paymentTerms: 'Net 30',
    isInternational: false,
    approvedBy: 'procurement_manager_1',
    notes: 'Rush order for weekend promotion'
  },
  {
    id: 'PO-2024-002',
    supplierId: '3',
    supplierName: 'MedSupply Pharmaceuticals',
    products: [
      {
        productId: '3',
        productName: 'Insulin Vials - Rapid Acting',
        quantity: 200,
        unitPrice: 85.00,
        totalPrice: 17000
      }
    ],
    totalAmount: 17000,
    status: 'shipped',
    createdDate: '2024-01-08T11:30:00Z',
    expectedDelivery: '2024-01-16T10:00:00Z',
    paymentTerms: 'Net 15',
    isInternational: false,
    approvedBy: 'procurement_manager_1'
  }
];

export const mockInventoryAlerts: InventoryAlert[] = [
  {
    id: '1',
    type: 'low_stock',
    productId: '1',
    productName: 'Organic Apples - Honeycrisp',
    currentStock: 500,
    threshold: 1000,
    message: 'Stock level below reorder point',
    urgency: 'high',
    createdDate: '2024-01-15T08:00:00Z',
    recommendedAction: 'Reorder 2000 units from Washington Organic Farms',
    recommendedSuppliers: [mockSuppliers[0]],
    estimatedStockoutDate: '2024-01-20',
    affectedWarehouses: ['Seattle Distribution Center']
  },
  {
    id: '2',
    type: 'expiration_warning',
    productId: '4',
    productName: 'Organic Spinach - Baby Leaves',
    currentStock: 200,
    message: 'Products expiring in 5 days',
    urgency: 'critical',
    createdDate: '2024-01-15T10:00:00Z',
    recommendedAction: 'Implement markdown pricing or transfer to high-turnover location',
    affectedWarehouses: ['Seattle Distribution Center']
  },
  {
    id: '3',
    type: 'temperature_breach',
    productId: '3',
    productName: 'Insulin Vials - Rapid Acting',
    currentStock: 500,
    message: 'Temperature exceeded safe range for 15 minutes',
    urgency: 'critical',
    createdDate: '2024-01-15T14:30:00Z',
    recommendedAction: 'Immediate quality inspection required',
    affectedWarehouses: ['San Francisco Pharma Hub']
  }
];

export const mockRiskAlerts: RiskAlert[] = [
  {
    id: '1',
    type: 'weather',
    severity: 'medium',
    message: 'Severe weather conditions may cause delays in Pacific Northwest',
    timestamp: '2024-01-15T12:00:00Z',
    resolved: false,
    affectedShipments: ['1', '2'],
    recommendedActions: ['Reroute through southern corridor', 'Delay non-urgent shipments'],
    estimatedImpact: '2-4 hour delays expected'
  },
  {
    id: '2',
    type: 'supplier',
    severity: 'high',
    message: 'TechCorp International experiencing production delays',
    timestamp: '2024-01-15T10:30:00Z',
    resolved: false,
    affectedProducts: ['2'],
    recommendedActions: ['Source from alternative supplier', 'Adjust inventory levels'],
    estimatedImpact: '1-2 week delay on new orders'
  },
  {
    id: '3',
    type: 'compliance',
    severity: 'critical',
    message: 'FDA inspection scheduled for pharmaceutical warehouse',
    timestamp: '2024-01-15T16:00:00Z',
    resolved: false,
    affectedProducts: ['3'],
    recommendedActions: ['Prepare compliance documentation', 'Schedule staff briefing'],
    estimatedImpact: 'Potential 1-day operational halt'
  }
];

export const mockShipments: Shipment[] = [
  {
    id: '1',
    trackingNumber: 'TRK-2024-001',
    products: [mockProducts[0]],
    origin: mockLocations[0],
    destination: mockLocations[4],
    currentLocation: mockLocations[1],
    status: 'in_transit',
    carrier: 'FastShip Logistics',
    transportMode: 'road',
    estimatedDelivery: '2024-01-16T14:00:00Z',
    route: [mockLocations[0], mockLocations[1], mockLocations[4]],
    deliveryPersonnel: mockDeliveryPersonnel[0],
    documents: [],
    riskAlerts: [mockRiskAlerts[0]],
    sustainabilityScore: 85,
    totalCost: 125.50,
    priority: 'high',
    specialHandling: ['temperature_controlled'],
    temperatureLog: [
      {
        timestamp: '2024-01-15T10:00:00Z',
        temperature: 2.5,
        humidity: 85,
        location: 'Seattle Distribution Center',
        sensorId: 'TEMP001'
      },
      {
        timestamp: '2024-01-15T14:00:00Z',
        temperature: 3.1,
        humidity: 82,
        location: 'In Transit',
        sensorId: 'TEMP001'
      }
    ]
  },
  {
    id: '2',
    trackingNumber: 'TRK-2024-002',
    products: [mockProducts[2]],
    origin: mockLocations[2],
    destination: mockLocations[4],
    currentLocation: mockLocations[2],
    status: 'out_for_delivery',
    carrier: 'MedExpress',
    transportMode: 'road',
    estimatedDelivery: '2024-01-16T10:00:00Z',
    route: [mockLocations[2], mockLocations[4]],
    deliveryPersonnel: mockDeliveryPersonnel[1],
    documents: [],
    riskAlerts: [],
    sustainabilityScore: 75,
    totalCost: 45.00,
    priority: 'express',
    specialHandling: ['pharmaceutical', 'temperature_controlled']
  }
];

export const mockWarehouses: Warehouse[] = [
  {
    id: '1',
    name: 'Seattle Distribution Center',
    location: mockLocations[0],
    capacity: 100000,
    currentLoad: 75000,
    manager: 'Alice Johnson',
    operationalStatus: 'active',
    products: [mockProducts[0], mockProducts[3]],
    lastInventoryCheck: '2024-01-15T08:00:00Z',
    alertsCount: 2,
    zones: [
      {
        id: 'zone1',
        name: 'Cold Storage A',
        type: 'cold_storage',
        capacity: 20000,
        currentLoad: 15000,
        temperatureRange: { min: 0, max: 4, unit: 'C' },
        specialRequirements: ['Temperature monitoring', 'Humidity control']
      },
      {
        id: 'zone2',
        name: 'General Storage',
        type: 'general',
        capacity: 60000,
        currentLoad: 45000
      }
    ],
    temperatureControlled: true,
    hazmatCertified: true,
    securityLevel: 'high',
    staffCount: 45,
    equipment: [
      {
        id: 'eq1',
        name: 'Forklift FL-001',
        type: 'forklift',
        status: 'operational',
        lastMaintenance: '2024-01-10',
        nextMaintenance: '2024-02-10',
        location: 'Zone A'
      }
    ]
  },
  {
    id: '2',
    name: 'Portland Cold Storage',
    location: mockLocations[1],
    capacity: 50000,
    currentLoad: 42000,
    manager: 'Bob Wilson',
    operationalStatus: 'active',
    products: [mockProducts[1]],
    lastInventoryCheck: '2024-01-15T09:30:00Z',
    alertsCount: 1,
    zones: [
      {
        id: 'zone3',
        name: 'Hazmat Storage',
        type: 'hazmat',
        capacity: 10000,
        currentLoad: 8000,
        specialRequirements: ['Hazmat certification', 'Fire suppression', 'Ventilation']
      }
    ],
    temperatureControlled: true,
    hazmatCertified: false,
    securityLevel: 'standard',
    staffCount: 25,
    equipment: []
  }
];

export const mockDemandForecasts: DemandForecast[] = [
  {
    productId: '1',
    productName: 'Organic Apples - Honeycrisp',
    region: 'Pacific Northwest',
    predictedDemand: 8500,
    confidence: 92,
    timeframe: 'Next 30 days',
    factors: ['Seasonal trends', 'Weather patterns', 'Historical sales']
  },
  {
    productId: '3',
    productName: 'Insulin Vials - Rapid Acting',
    region: 'California',
    predictedDemand: 1200,
    confidence: 88,
    timeframe: 'Next 30 days',
    factors: ['Patient demographics', 'Insurance coverage', 'Prescription trends']
  }
];

export const mockOptimizationSuggestions: OptimizationSuggestion[] = [
  {
    id: 'opt1',
    type: 'inventory_reduction',
    title: 'Reduce Slow-Moving Inventory',
    description: 'Implement markdown pricing for products with low turnover rates',
    impact: 'medium',
    estimatedSavings: 15000,
    implementationCost: 2000,
    timeToImplement: 7,
    affectedProducts: ['4'],
    affectedWarehouses: ['1']
  },
  {
    id: 'opt2',
    type: 'supplier_consolidation',
    title: 'Consolidate Organic Suppliers',
    description: 'Reduce supplier count by consolidating orders with top-performing vendors',
    impact: 'high',
    estimatedSavings: 45000,
    implementationCost: 8000,
    timeToImplement: 30,
    affectedProducts: ['1', '4']
  }
];

export const mockUsers: User[] = [
  {
    id: '1',
    name: 'John Smith',
    email: 'john.smith@company.com',
    role: 'warehouse_manager',
    permissions: ['view_inventory', 'edit_inventory', 'create_orders', 'manage_suppliers'],
    lastLogin: '2024-01-15T09:30:00Z',
    warehouseAccess: ['1', '2'],
    department: 'Operations',
    isActive: true
  },
  {
    id: '2',
    name: 'Sarah Davis',
    email: 'sarah.davis@company.com',
    role: 'procurement_manager',
    permissions: ['view_inventory', 'create_orders', 'approve_orders', 'manage_suppliers', 'view_analytics'],
    lastLogin: '2024-01-15T08:15:00Z',
    warehouseAccess: ['1', '2', '3'],
    department: 'Procurement',
    isActive: true
  }
];

export const mockAnalytics: Analytics = {
  totalShipments: 15842,
  onTimeDelivery: 94.2,
  inventoryTurnover: 12.5,
  sustainabilityScore: 87,
  costSavings: 2.3,
  riskMitigated: 89,
  customerSatisfaction: 96.8,
  warehouseEfficiency: 91.5,
  demandForecast: mockDemandForecasts,
  supplierPerformance: [
    mockSuppliers[0].performanceMetrics,
    mockSuppliers[1].performanceMetrics,
    mockSuppliers[2].performanceMetrics
  ],
  inventoryOptimization: mockOptimizationSuggestions
};