import React, { useState } from 'react';
import { Header } from './components/Layout/Header';
import { Sidebar } from './components/Layout/Sidebar';
import { Dashboard } from './components/Dashboard/Dashboard';
import { InventoryControl } from './components/Inventory/InventoryControl';
import { SupplierManagement } from './components/Suppliers/SupplierManagement';
import { PurchaseOrderManagement } from './components/Procurement/PurchaseOrderManagement';
import { LiveTrackingMap } from './components/Tracking/LiveTrackingMap';
import { WarehouseGrid } from './components/Warehouses/WarehouseGrid';
import { ComplianceMatrix } from './components/Compliance/ComplianceMatrix';
import { SustainabilityDashboard } from './components/Sustainability/SustainabilityDashboard';
import { CustomerPortal } from './components/Customer/CustomerPortal';
import { AnalyticsDashboard } from './components/Analytics/AnalyticsDashboard';
import { SafetyCompliance } from './components/Safety/SafetyCompliance';
import { useWebSocket } from './hooks/useWebSocket';
import { 
  mockProducts, 
  mockShipments, 
  mockWarehouses, 
  mockInventoryAlerts,
  mockRiskAlerts,
  mockSuppliers,
  mockPurchaseOrders,
  mockAnalytics
} from './data/mockData';

function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [currentUser] = useState('John Smith');
  const [notificationCount] = useState(8);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Simulate real-time updates
  const { isConnected, lastMessage } = useWebSocket('ws://localhost:8080');

  const handleSidebarToggle = () => {
    if (window.innerWidth >= 1024) {
      setSidebarCollapsed(!sidebarCollapsed);
    } else {
      setIsMobileMenuOpen(!isMobileMenuOpen);
    }
  };

  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
    if (window.innerWidth < 1024) {
      setIsMobileMenuOpen(false);
    }
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard />;
      case 'inventory':
        return <InventoryControl products={mockProducts} alerts={mockInventoryAlerts} />;
      case 'suppliers':
        return <SupplierManagement suppliers={mockSuppliers} />;
      case 'procurement':
        return <PurchaseOrderManagement purchaseOrders={mockPurchaseOrders} suppliers={mockSuppliers} />;
      case 'shipments':
        return <CustomerPortal shipments={mockShipments} />;
      case 'warehouses':
        return <WarehouseGrid warehouses={mockWarehouses} />;
      case 'tracking':
        return <LiveTrackingMap shipments={mockShipments} />;
      case 'compliance':
        return <ComplianceMatrix products={mockProducts} />;
      case 'safety':
        return <SafetyCompliance products={mockProducts} />;
      case 'sustainability':
        return <SustainabilityDashboard shipments={mockShipments} products={mockProducts} />;
      case 'analytics':
        return <AnalyticsDashboard analytics={mockAnalytics} />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <Header 
        currentUser={currentUser} 
        notificationCount={notificationCount}
        onSidebarToggle={handleSidebarToggle}
        sidebarCollapsed={sidebarCollapsed}
      />
      
      <div className="flex">
        <Sidebar 
          activeTab={activeTab} 
          onTabChange={handleTabChange}
          collapsed={sidebarCollapsed}
          isMobileOpen={isMobileMenuOpen}
          onMobileClose={() => setIsMobileMenuOpen(false)}
        />
        
        <main className={`flex-1 transition-all duration-300 ease-in-out ${
          sidebarCollapsed ? 'lg:ml-16' : 'lg:ml-64'
        }`}>
          <div className="p-6 lg:p-8">
            <div className="max-w-7xl mx-auto">
              {renderContent()}
            </div>
          </div>
        </main>
      </div>
      
      {/* Mobile Overlay */}
      {isMobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}
      
      {/* Real-time connection indicator */}
      {isConnected && (
        <div className="fixed bottom-6 right-6 bg-emerald-500 text-white px-4 py-2 rounded-full text-sm flex items-center space-x-2 shadow-lg z-30">
          <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
          <span className="font-medium">Live Updates Active</span>
        </div>
      )}

      {/* System Status Indicator */}
      <div className="fixed bottom-6 left-6 bg-white rounded-lg shadow-lg p-4 text-sm z-30 border border-slate-200">
        <div className="flex items-center space-x-3">
          <div className="w-3 h-3 bg-emerald-500 rounded-full"></div>
          <span className="text-slate-700 font-medium">All Systems Operational</span>
        </div>
      </div>
    </div>
  );
}

export default App;