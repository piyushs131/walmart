export interface Product {
  id: string;
  name: string;
  category: ProductCategory;
  origin: string;
  batchNumber: string;
  quantity: number;
  price: number;
  expiryDate?: string;
  sustainabilityScore: number;
  authenticity: AuthenticityStatus;
  complianceStatus: ComplianceStatus;
  currentLocation: Location;
  warehouse: string;
  supplier: string;
  riskScore: number;
  co2Emissions: number;
  lastUpdated: string;
  fifoDate: string;
  reorderPoint: number;
  maxStock: number;
  minStock: number;
  handlingInstructions?: string;
  temperatureRange?: TemperatureRange;
  hazardClass?: HazardClass;
  barcode: string;
  rfidTag?: string;
}

export interface Supplier {
  id: string;
  name: string;
  location: Location;
  rating: number;
  avgDeliveryTime: number;
  pricePerUnit: number;
  capacity: number;
  sustainability: number;
  contactInfo: ContactInfo;
  certifications: Certification[];
  paymentTerms: string;
  minimumOrder: number;
  isInternational: boolean;
  customsDocuments?: Document[];
  performanceMetrics: SupplierMetrics;
  products: string[];
  lastOrderDate: string;
  totalOrders: number;
  onTimeDeliveryRate: number;
  qualityScore: number;
  complianceStatus: ComplianceStatus;
}

export interface Location {
  id: string;
  name: string;
  address: string;
  coordinates: {
    lat: number;
    lng: number;
  };
  type: LocationType;
  capacity?: number;
  currentLoad?: number;
  temperatureControlled?: boolean;
  hazmatCertified?: boolean;
  securityLevel?: SecurityLevel;
}

export interface Shipment {
  id: string;
  trackingNumber: string;
  products: Product[];
  origin: Location;
  destination: Location;
  currentLocation: Location;
  status: ShipmentStatus;
  carrier: string;
  transportMode: TransportMode;
  estimatedDelivery: string;
  actualDelivery?: string;
  route: Location[];
  deliveryPersonnel?: DeliveryPersonnel;
  customsStatus?: CustomsStatus;
  documents: Document[];
  riskAlerts: RiskAlert[];
  sustainabilityScore: number;
  totalCost: number;
  priority: Priority;
  specialHandling?: SpecialHandling[];
  temperatureLog?: TemperatureReading[];
  proofOfDelivery?: ProofOfDelivery;
}

export interface DeliveryPersonnel {
  id: string;
  name: string;
  phone: string;
  vehicleNumber: string;
  currentLocation: {
    lat: number;
    lng: number;
  };
  rating: number;
  certifications: string[];
  hazmatCertified: boolean;
  activeDeliveries: string[];
  maxCapacity: number;
  currentLoad: number;
}

export interface PurchaseOrder {
  id: string;
  supplierId: string;
  supplierName: string;
  products: OrderItem[];
  totalAmount: number;
  status: OrderStatus;
  createdDate: string;
  expectedDelivery: string;
  actualDelivery?: string;
  paymentTerms: string;
  isInternational: boolean;
  customsDocuments?: Document[];
  approvedBy: string;
  notes?: string;
}

export interface OrderItem {
  productId: string;
  productName: string;
  quantity: number;
  unitPrice: number;
  totalPrice: number;
  specifications?: string;
}

export interface InventoryAlert {
  id: string;
  type: AlertType;
  productId: string;
  productName: string;
  currentStock: number;
  threshold?: number;
  message: string;
  urgency: Urgency;
  createdDate: string;
  resolvedDate?: string;
  recommendedAction: string;
  recommendedSuppliers?: Supplier[];
  estimatedStockoutDate?: string;
  affectedWarehouses: string[];
}

export interface Warehouse {
  id: string;
  name: string;
  location: Location;
  capacity: number;
  currentLoad: number;
  manager: string;
  operationalStatus: OperationalStatus;
  products: Product[];
  lastInventoryCheck: string;
  alertsCount: number;
  zones: WarehouseZone[];
  temperatureControlled: boolean;
  hazmatCertified: boolean;
  securityLevel: SecurityLevel;
  staffCount: number;
  equipment: Equipment[];
}

export interface WarehouseZone {
  id: string;
  name: string;
  type: ZoneType;
  capacity: number;
  currentLoad: number;
  temperatureRange?: TemperatureRange;
  specialRequirements?: string[];
}

export interface Analytics {
  totalShipments: number;
  onTimeDelivery: number;
  inventoryTurnover: number;
  sustainabilityScore: number;
  costSavings: number;
  riskMitigated: number;
  customerSatisfaction: number;
  warehouseEfficiency: number;
  demandForecast: DemandForecast[];
  supplierPerformance: SupplierMetrics[];
  inventoryOptimization: OptimizationSuggestion[];
}

export interface DemandForecast {
  productId: string;
  productName: string;
  region: string;
  predictedDemand: number;
  confidence: number;
  timeframe: string;
  factors: string[];
}

export interface OptimizationSuggestion {
  id: string;
  type: OptimizationType;
  title: string;
  description: string;
  impact: ImpactLevel;
  estimatedSavings: number;
  implementationCost: number;
  timeToImplement: number;
  affectedProducts?: string[];
  affectedWarehouses?: string[];
}

export interface SupplierMetrics {
  supplierId: string;
  supplierName: string;
  totalOrders: number;
  onTimeDeliveryRate: number;
  qualityScore: number;
  averageLeadTime: number;
  costPerformance: number;
  sustainabilityScore: number;
  complianceScore: number;
  riskScore: number;
}

export interface RiskAlert {
  id: string;
  type: RiskType;
  severity: Severity;
  message: string;
  timestamp: string;
  resolved: boolean;
  affectedShipments?: string[];
  affectedProducts?: string[];
  recommendedActions: string[];
  estimatedImpact: string;
}

export interface Document {
  id: string;
  type: DocumentType;
  name: string;
  status: DocumentStatus;
  expiryDate?: string;
  downloadUrl: string;
  uploadedBy: string;
  uploadedDate: string;
  version: number;
}

export interface Certification {
  id: string;
  name: string;
  issuingBody: string;
  issueDate: string;
  expiryDate: string;
  status: CertificationStatus;
  documentUrl: string;
}

export interface ContactInfo {
  primaryContact: string;
  email: string;
  phone: string;
  alternatePhone?: string;
  address: string;
  website?: string;
}

export interface TemperatureRange {
  min: number;
  max: number;
  unit: 'C' | 'F';
}

export interface TemperatureReading {
  timestamp: string;
  temperature: number;
  humidity?: number;
  location: string;
  sensorId: string;
}

export interface ProofOfDelivery {
  deliveredBy: string;
  receivedBy: string;
  timestamp: string;
  signature?: string;
  photo?: string;
  notes?: string;
  condition: DeliveryCondition;
}

export interface Equipment {
  id: string;
  name: string;
  type: EquipmentType;
  status: EquipmentStatus;
  lastMaintenance: string;
  nextMaintenance: string;
  location: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  permissions: Permission[];
  lastLogin: string;
  warehouseAccess: string[];
  department: string;
  isActive: boolean;
}

// Enums and Types
export type ProductCategory = 'groceries' | 'hazardous' | 'perishables' | 'electronics' | 'clothing' | 'pharmaceuticals' | 'luxury' | 'automotive' | 'industrial';
export type LocationType = 'warehouse' | 'distribution_center' | 'retail_store' | 'customer' | 'supplier' | 'customs' | 'port' | 'airport' | 'manufacturing';
export type ShipmentStatus = 'pending' | 'in_transit' | 'customs_clearance' | 'out_for_delivery' | 'delivered' | 'delayed' | 'exception' | 'returned';
export type TransportMode = 'road' | 'rail' | 'air' | 'sea' | 'multimodal' | 'drone' | 'pipeline';
export type AuthenticityStatus = 'verified' | 'pending' | 'suspicious' | 'counterfeit';
export type ComplianceStatus = 'compliant' | 'pending_review' | 'non_compliant' | 'exempt' | 'expired';
export type CustomsStatus = 'pending' | 'cleared' | 'inspection_required' | 'detained' | 'released' | 'documentation_required';
export type RiskType = 'delay' | 'damage' | 'theft' | 'weather' | 'customs' | 'compliance' | 'quality' | 'temperature' | 'expiration' | 'supplier';
export type Severity = 'low' | 'medium' | 'high' | 'critical';
export type DocumentType = 'invoice' | 'customs_declaration' | 'certificate' | 'insurance' | 'permit' | 'manifest' | 'msds' | 'coa' | 'bill_of_lading';
export type DocumentStatus = 'valid' | 'expired' | 'pending' | 'rejected' | 'under_review';
export type Urgency = 'low' | 'medium' | 'high' | 'critical';
export type Priority = 'low' | 'medium' | 'high' | 'express' | 'emergency';
export type OperationalStatus = 'active' | 'maintenance' | 'closed' | 'limited_capacity' | 'emergency';
export type UserRole = 'admin' | 'warehouse_manager' | 'inventory_specialist' | 'delivery_personnel' | 'customer' | 'compliance_officer' | 'procurement_manager' | 'quality_control';
export type AlertType = 'low_stock' | 'expiration_warning' | 'high_demand' | 'reorder_point' | 'temperature_breach' | 'compliance_issue' | 'quality_alert';
export type OrderStatus = 'draft' | 'pending_approval' | 'approved' | 'sent_to_supplier' | 'confirmed' | 'in_production' | 'shipped' | 'delivered' | 'cancelled';
export type SecurityLevel = 'standard' | 'high' | 'maximum' | 'restricted';
export type ZoneType = 'general' | 'cold_storage' | 'freezer' | 'hazmat' | 'pharmaceutical' | 'high_value' | 'quarantine' | 'staging';
export type HazardClass = 'class_1' | 'class_2' | 'class_3' | 'class_4' | 'class_5' | 'class_6' | 'class_7' | 'class_8' | 'class_9';
export type SpecialHandling = 'fragile' | 'hazmat' | 'temperature_controlled' | 'high_value' | 'pharmaceutical' | 'food_grade' | 'sterile';
export type DeliveryCondition = 'excellent' | 'good' | 'fair' | 'damaged' | 'rejected';
export type EquipmentType = 'forklift' | 'conveyor' | 'scanner' | 'scale' | 'temperature_sensor' | 'security_camera' | 'dock_door' | 'crane';
export type EquipmentStatus = 'operational' | 'maintenance_required' | 'out_of_service' | 'scheduled_maintenance';
export type CertificationStatus = 'valid' | 'expired' | 'pending_renewal' | 'suspended';
export type OptimizationType = 'inventory_reduction' | 'supplier_consolidation' | 'route_optimization' | 'warehouse_transfer' | 'markdown_opportunity' | 'automation';
export type ImpactLevel = 'low' | 'medium' | 'high' | 'critical';
export type Permission = 'view_inventory' | 'edit_inventory' | 'create_orders' | 'approve_orders' | 'manage_suppliers' | 'view_analytics' | 'manage_users' | 'system_admin';