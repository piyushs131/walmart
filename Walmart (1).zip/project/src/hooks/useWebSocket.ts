import { useEffect, useRef, useState } from 'react';

export const useWebSocket = (url: string) => {
  const [isConnected, setIsConnected] = useState(false);
  const [lastMessage, setLastMessage] = useState<any>(null);
  const wsRef = useRef<WebSocket | null>(null);

  useEffect(() => {
    // Simulate WebSocket connection for real-time updates
    const simulateWebSocket = () => {
      setIsConnected(true);
      
      const interval = setInterval(() => {
        const mockUpdates = [
          {
            type: 'location_update',
            data: {
              shipmentId: '1',
              location: { lat: 45.5200 + Math.random() * 0.01, lng: -122.6750 + Math.random() * 0.01 },
              timestamp: new Date().toISOString()
            }
          },
          {
            type: 'inventory_alert',
            data: {
              productId: '1',
              currentStock: Math.floor(Math.random() * 1000),
              timestamp: new Date().toISOString()
            }
          },
          {
            type: 'risk_alert',
            data: {
              type: 'weather',
              severity: 'medium',
              message: 'Traffic congestion detected on route',
              timestamp: new Date().toISOString()
            }
          }
        ];

        const randomUpdate = mockUpdates[Math.floor(Math.random() * mockUpdates.length)];
        setLastMessage(randomUpdate);
      }, 5000);

      return () => {
        clearInterval(interval);
        setIsConnected(false);
      };
    };

    const cleanup = simulateWebSocket();
    return cleanup;
  }, [url]);

  const sendMessage = (message: any) => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify(message));
    }
  };

  return { isConnected, lastMessage, sendMessage };
};